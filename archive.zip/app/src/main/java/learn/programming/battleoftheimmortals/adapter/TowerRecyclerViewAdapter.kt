package learn.programming.battleoftheimmortals.adapter

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.fragment_floor.view.*
import kotlinx.android.synthetic.main.item_floor.view.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.activity.MainActivity
import learn.programming.battleoftheimmortals.database.model.tower.Floor
import learn.programming.battleoftheimmortals.fragment.main.champion.FloorFragment


class TowerRecyclerViewAdapter(val context: Context, private var floors: List<Floor>) :
    RecyclerView.Adapter<TowerRecyclerViewAdapter.MyViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.item_floor, parent, false)

        return MyViewHolder(view)
    }

    override fun getItemCount(): Int {
        return floors.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.view.floorBtn.text = ("${floors[position].name}")
        holder.view.floorBtn.layoutParams.width = 170 + (position * 25)
        holder.view.floorBtn.textSize = 10f + (position * 0.4f)
        if (position % 5 == 0){
            holder.view.floorBtn.textSize = 15f
            holder.view.floorBtn.setTextColor(Color.parseColor("#DDF7CE3A"))
        }else{
            holder.view.floorBtn.setTextColor(Color.parseColor("#ffffff"))
        }
        holder.view.floorBtn.setOnClickListener {
            (context as MainActivity).changeFragmentTo(FloorFragment(floors[position]))
        }
    }

    class MyViewHolder(val view: View) : RecyclerView.ViewHolder(view)
}
