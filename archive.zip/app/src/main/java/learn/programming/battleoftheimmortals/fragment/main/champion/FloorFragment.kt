package learn.programming.battleoftheimmortals.fragment.main.champion


import android.content.res.ColorStateList
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ImageView
import androidx.fragment.app.Fragment
import de.hdodenhof.circleimageview.CircleImageView
import kotlinx.android.synthetic.main.fragment_floor.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.adapter.TowerChampionSpinner
import learn.programming.battleoftheimmortals.database.model.actor.Champion
import learn.programming.battleoftheimmortals.database.model.tower.Floor
import learn.programming.battleoftheimmortals.utility.AccountObject

/**
 * A simple [Fragment] subclass.
 */
class FloorFragment(private val floor: Floor) : Fragment() {


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_floor, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        lateinit var champ: Champion


        towerSpinner.adapter =
            TowerChampionSpinner(context!!, AccountObject.currentAccount!!.champions)

        //Tower Champion Spinner
        towerSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val champion = parent?.getItemAtPosition(position) as Champion
                contestant2IV.setImageResource(champion.profession.pic)
                champ = champion
            }

        }


        // Background change based on floor
        when {
            floor.ID in 0..4 -> floorBackgroundCL.setBackgroundResource(R.drawable.tower_backgorund2)
            floor.ID in 5..9 -> floorBackgroundCL.setBackgroundResource(R.drawable.tower_background4)
            floor.ID in 10..14 -> floorBackgroundCL.setBackgroundResource(R.drawable.tower_background3)
            else -> floorBackgroundCL.setBackgroundResource(R.drawable.tower_background1)
        }

        when (floor.monsters.size) {
            1 -> {
                enemyExists(enemy1IV, enemy1Frame, 0)

            }
            2 -> {
                enemyExists(enemy1IV, enemy1Frame, 0)
                enemyExists(enemy3IV, enemy3Frame, 1)
            }
            3 -> {
                enemyExists(enemy1IV, enemy1Frame, 0)
                enemyExists(enemy2IV, enemy2Frame, 1)
                enemyExists(enemy3IV, enemy3Frame, 2)
            }
            4 -> {
                enemyExists(enemy1IV, enemy1Frame, 0)
                enemyExists(enemy2IV, enemy2Frame, 1)
                enemyExists(enemy3IV, enemy3Frame, 2)
                enemyExists(enemy4IV, enemy4Frame, 3)
            }
            5 -> {
                enemyExists(enemy1IV, enemy1Frame, 0)
                enemyExists(enemy2IV, enemy2Frame, 1)
                enemyExists(enemy3IV, enemy3Frame, 2)
                enemyExists(enemy4IV, enemy4Frame, 3)
                enemyExists(enemy5IV, enemy5Frame, 4)
            }
        }

        //Ability power progress
        if (towerAbilityPB.progress == 100) {
            towerAbilityPB.progressTintList = ColorStateList.valueOf(context?.resources?.getColor(R.color.Purple) ?: 0x000)

        }
    }

    private fun enemyExists(imageView: CircleImageView, frame: ImageView, position: Int) {
        imageView.visibility = View.VISIBLE
        frame.visibility = View.VISIBLE
        imageView.setImageResource(floor.monsters[position]?.profession!!.icon)
    }
}


