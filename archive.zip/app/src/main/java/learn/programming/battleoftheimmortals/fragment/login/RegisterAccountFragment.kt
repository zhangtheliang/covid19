package learn.programming.battleoftheimmortals.fragment.login


import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.fragment_register_account.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.activity.LoginActivity
import learn.programming.battleoftheimmortals.database.DBM
import learn.programming.battleoftheimmortals.database.model.account.Account
import learn.programming.battleoftheimmortals.utility.AccountObject

class RegisterAccountFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_register_account, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        registerBtn.setOnClickListener {
            var username = userNameET.text.toString()
            var password = passwordET.text.toString()
            var password2 = passwordRepeatET.text.toString()

            if (username.length <= 3 != password.length <= 3 != (username.length <= 3 && password.length <= 3)){
                Toast.makeText(this.context, "Each field needs to include at least 4 characters", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (password != password2){
                Toast.makeText(this.context, "Password don't match", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (AccountObject.validateRegister(username) == false){
                Toast.makeText(this.context, "Username already exists.", Toast.LENGTH_LONG).show()
                userNameET.setBackgroundColor(Color.RED)
                return@setOnClickListener
            }

            var acc = Account(
                username,
                password
            )
            DBM.getSharedInstance().accountDao().save(acc)
            (activity as LoginActivity).changeFragmentTo(LoginFragment())
        }
    }
}
