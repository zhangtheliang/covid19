package learn.programming.battleoftheimmortals.database.model.account

class Stat(var type: StatType, var value: Int){

    enum class StatType{
        WISDOM,
        STRENGTH,
        AGILITY,
        INTELLECT,
        CRIT_RATE,
        HIT_POINTS,
        ARMOR,
        DAMAGE,
        HEAL,
        ACCURACY,
        EVASION,
        ATTACK_SPEED
    }

    constructor(encodedVal: String) : this(StatType.DAMAGE, 0){
        val data = encodedVal.split("#")
        val typeOrdinal = data[0].toIntOrNull() ?: 0
        val _value = data[1].toIntOrNull() ?: 0
        type = StatType.values()[typeOrdinal]
        value = _value
    }

    override fun toString(): String {
        //type.ordinal = 5, value = 144 = 5#144
        return "${type.ordinal}#$value"
    }
}