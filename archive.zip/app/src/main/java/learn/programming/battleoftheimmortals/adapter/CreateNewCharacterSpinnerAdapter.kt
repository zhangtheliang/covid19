package learn.programming.battleoftheimmortals.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.spinner_item.view.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.database.model.actor.Profession
import learn.programming.battleoftheimmortals.database.model.actor.Race

class CreateNewCharacterSpinnerAdapter(context: Context, items: List<Any>) : ArrayAdapter<Any>(context, R.layout.spinner_item, R.id.spinnerItemTV, items) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view = convertView
        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.spinner_item, null, false)
        }

        val currentItem = getItem(position)
        when(currentItem){
            is Profession -> {
                view?.spinnerItemTV?.text = (currentItem as Profession).name
            }
            is Race -> {
                view?.spinnerItemTV?.text = (currentItem as Race).name
            }
        }

        when (currentItem){
            is Profession ->{
                view?.spinnerItemRaceIV?.visibility = View.GONE
                view?.spinnerItemProfessionIV?.setImageResource(currentItem.icon)
            }

            is Race ->{
                view?.spinnerItemProfessionIV?.visibility = View.GONE
                view?.spinnerItemRaceIV?.setImageResource(currentItem.icon)
            }
        }
        return view!!
    }

    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
        return getView(position, convertView, parent)
    }

}