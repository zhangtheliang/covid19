package learn.programming.battleoftheimmortals.database.model.actor

import learn.programming.battleoftheimmortals.R

enum class Profession(
    val id: Int,
    val hitPoints: Int,
    val armor: Int,
    val damage: Int,
    val heal: Int = 0,
    val accuracy: Int = 0,
    val critChance: Int = 0,
    val evasion: Int = 0,
    val icon: Int = 0,
    val pic: Int = 0
) {
    GLADIATOR(0, 1150, 16, 25, 0, 15, 10, 3, R.drawable.gladiator, R.drawable.photo_warrior2),
    KNIGHT(1, 1500, 22, 18, 0, 15, 5, 2, R.drawable.knight,R.drawable.photo_knight),
    MAGE(2, 850, 10, 60, 0, 11, 5, 20, R.drawable.mage,R.drawable.photo_sorc1),
    ASSASSIN(3, 1050, 10, 28, 0, 33, 8, 20, R.drawable.assassin,R.drawable.photo_sin2),
    ARCHER(4, 950, 10, 32, 0, 31, 20, 16, R.drawable.ranger,R.drawable.photo_archer),
    PRIEST(5, 1200, 12, 22, 22, 20, 5,2, R.drawable.priest,R.drawable.photo_sorc2);

    companion object {
        fun getById(id: Int): Profession {
            return Profession.values().filter { it.id == id }.first()
        }
    }
}