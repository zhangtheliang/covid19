package learn.programming.battleoftheimmortals.utility

import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import learn.programming.battleoftheimmortals.activity.FightActivity
import learn.programming.battleoftheimmortals.activity.FightActivity.HitType
import learn.programming.battleoftheimmortals.database.model.actor.Actor


object FightSimulator {
    var combatLog: String = ""
    lateinit var activity: FightActivity
    lateinit var contestant1: Actor
    lateinit var contestant2: Actor


fun simulateFight(activity: FightActivity,
                  contestant1: Actor,
                  contestant2: Actor,
                  hitBox: ImageView,
                  tv: TextView,
                  hitType: HitType,
                  bar: ProgressBar) {
        this.activity = activity
        this.contestant1 = contestant1
        this.contestant2 = contestant2
        if (contestant1.isDead()!= true){
            tv.setText("Dead")
        } else if(contestant2.isDead() != false){
                simulateHit(hitBox, tv, bar, hitType)
        }else{
            tv.setText("Dead")
        }
    }

    private fun simulateHit(hitBox: ImageView,tv: TextView,bar: ProgressBar, hitType: HitType) {
        if (hitType == HitType.NORMAL_HIT) {
            if (attemptHit(contestant1, contestant2)) {
                val hpPercentage = contestant2.maxHitPoints.value / 100
                hitBox.visibility = View.VISIBLE
                tv.setText("${contestant2.takeDamage(contestant1.getDamangeOnHit(contestant2))}  ")
                bar.progress = contestant2.hitPoints.value / hpPercentage
            } else {
                tv.setText("Missed")
            }
        }else if (hitType == HitType.SKILL){
            val hpPercentage = contestant2.maxHitPoints.value / 100
            hitBox.visibility = View.VISIBLE
            tv.setText("${contestant2.takeDamage(contestant1.getDamangeOnHit(contestant2)) * 2}  ")
            bar.progress = contestant2.hitPoints.value / hpPercentage
        }
    }

    private fun attemptHit(caster: Actor, target: Actor): Boolean {
        val r = (1..100).random()
        return caster.getHitChance(target) >= r
    }
}