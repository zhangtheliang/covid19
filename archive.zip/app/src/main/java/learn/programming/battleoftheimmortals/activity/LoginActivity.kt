package learn.programming.battleoftheimmortals.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.fragment.login.LoginFragment

class LoginActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        changeFragmentTo(LoginFragment())
    }

    fun changeFragmentTo(fragment: Fragment) {
        supportFragmentManager
            .beginTransaction()
            .addToBackStack(fragment.javaClass.name)
            .replace(R.id.fragmentHolder, fragment)
            .commit()
    }
}
