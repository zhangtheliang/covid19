package learn.programming.battleoftheimmortals.database.dao

import androidx.room.*
import learn.programming.battleoftheimmortals.database.model.actor.InventoryItem


@Dao
interface InventoryItemDao{
    @Query("SELECT * FROM InventoryItem WHERE ownerID=:ownerID")
    fun getAllForOwner(ownerID: Int) : List<InventoryItem>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insert(item: InventoryItem) : Long

    @Update
    fun update(item: InventoryItem)

    @Transaction
    fun save(item: InventoryItem) {
        if(item.equipedSlot == 0){
            //inventory item
        }
        val id: Long = insert(item)
        if (id == -1L) {
            update(item)
        }
    }

    @Delete
    fun remove(item: InventoryItem)
}
