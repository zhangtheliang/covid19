package learn.programming.battleoftheimmortals.fragment.main.champion


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.fragment_equiped_items.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.database.model.actor.Champion
import learn.programming.battleoftheimmortals.database.model.actor.Profession
import learn.programming.battleoftheimmortals.utility.ItemObject

/**
 * A simple [Fragment] subclass.
 */
class EquipedItemsFragment(var champ: Champion) : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_equiped_items, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (champ.profession == Profession.GLADIATOR) {
            backgroundIV.setImageResource(R.drawable.photo_warrior2)
        }
        if (champ.profession == Profession.ASSASSIN) {
            backgroundIV.setImageResource(R.drawable.photo_sin1)
        }
        if (champ.profession == Profession.ARCHER) {
            backgroundIV.setImageResource(R.drawable.photo_archer2)
        }
        if (champ.profession == Profession.MAGE) {
            backgroundIV.setImageResource(R.drawable.photo_sorc1)
        }
        if (champ.profession == Profession.PRIEST) {
            backgroundIV.setImageResource(R.drawable.proho_priest)
        }
        if (champ.profession == Profession.KNIGHT) {
            backgroundIV.setImageResource(R.drawable.photo_knight)
        }

        champNameTV.setText(champ.name)

//      HELMET IMAGEVIEW AND FUNCTIONS
        helmetIC.updateView(champ.helmet)

        helmetIC.setOnClickListener {
            champ.helmet = champ.unequipItem(champ.helmet, ItemObject.helmets)
            val ft = fragmentManager!!.beginTransaction()
            ft.detach(this).attach(this).commit()
        }

        necklaceIC.updateView(champ.necklace)

        necklaceIC.setOnClickListener {
            champ.necklace = champ.unequipItem(champ.necklace, ItemObject.necklaces)
            val ft = fragmentManager!!.beginTransaction()
            ft.detach(this).attach(this).commit()
        }

        earringLeftIc.updateView(champ.earring1)
        earringLeftIc.setOnClickListener {
            champ.earring1 = champ.unequipItem(champ.earring1, ItemObject.earrings)
            val ft = fragmentManager!!.beginTransaction()
            ft.detach(this).attach(this).commit()
        }

        earringRightIc.updateView(champ.earring2)
        earringRightIc.setOnClickListener {
            champ.earring2 = champ.unequipItem(champ.earring2, ItemObject.earrings)
            val ft = fragmentManager!!.beginTransaction()
            ft.detach(this).attach(this).commit()
        }

        chestIC.updateView(champ.chestarmor)
        chestIC.setOnClickListener {
            champ.chestarmor = champ.unequipItem(champ.chestarmor, ItemObject.chest)
            val ft = fragmentManager!!.beginTransaction()
            ft.detach(this).attach(this).commit()
        }

        glovesIC.updateView(champ.gloves)
        glovesIC.setOnClickListener {
            champ.gloves = champ.unequipItem(champ.gloves, ItemObject.gloves)
            val ft = fragmentManager!!.beginTransaction()
            ft.detach(this).attach(this).commit()
        }

        bootsIC.updateView(champ.boots)
        bootsIC.setOnClickListener {
            champ.boots = champ.unequipItem(champ.boots, ItemObject.boots)
            val ft = fragmentManager!!.beginTransaction()
            ft.detach(this).attach(this).commit()
        }

        ringLeftIC.updateView(champ.ring1)
        ringLeftIC.setOnClickListener {
            champ.ring1 = champ.unequipItem(champ.ring1, ItemObject.rings)
            val ft = fragmentManager!!.beginTransaction()
            ft.detach(this).attach(this).commit()
        }

        ringRightIC.updateView(champ.ring2)
        ringRightIC.setOnClickListener {
            champ.ring2 = champ.unequipItem(champ.ring2, ItemObject.rings)
            val ft = fragmentManager!!.beginTransaction()
            ft.detach(this).attach(this).commit()
        }

        beltIC.updateView(champ.belt)
        beltIC.setOnClickListener {
            champ.belt = champ.unequipItem(champ.belt, ItemObject.belts)
            val ft = fragmentManager!!.beginTransaction()
            ft.detach(this).attach(this).commit()
        }

        weapon1IC.updateView(champ.weapon1)
        weapon1IC.setOnClickListener {
            champ.weapon1 = champ.unequipItem(champ.weapon1, ItemObject.weapon)
            val ft = fragmentManager!!.beginTransaction()
            ft.detach(this).attach(this).commit()
        }

        weapon2IC.updateView(champ.weapon2)
        weapon2IC.setOnClickListener {
            champ.weapon2 = champ.unequipItem(champ.weapon2, ItemObject.weapon)
            val ft = fragmentManager!!.beginTransaction()
            ft.detach(this).attach(this).commit()
        }

    }
}
