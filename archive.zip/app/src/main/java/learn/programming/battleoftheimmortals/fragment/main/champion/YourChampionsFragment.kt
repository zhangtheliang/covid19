package learn.programming.battleoftheimmortals.fragment.main.champion


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.graphics.alpha
import androidx.core.graphics.toColor
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.fragment_your_champions.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.activity.MainActivity
import learn.programming.battleoftheimmortals.adapter.YourChampionsListViewAdapter

/**
 * A simple [Fragment] subclass.
 */
class YourChampionsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_your_champions, container, false)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val listView = listOfChampions
        listView.adapter = YourChampionsListViewAdapter(this.context!!)


        newCharImg.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(CreateChampionFragment())
        }
    }
}
