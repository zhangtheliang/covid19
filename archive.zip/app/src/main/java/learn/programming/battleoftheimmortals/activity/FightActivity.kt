package learn.programming.battleoftheimmortals.activity

import android.graphics.Color
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import de.hdodenhof.circleimageview.CircleImageView
import kotlinx.android.synthetic.main.activity_fight.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.activity.FightActivity.HitType.NORMAL_HIT
import learn.programming.battleoftheimmortals.activity.FightActivity.HitType.SKILL
import learn.programming.battleoftheimmortals.database.model.actor.Actor
import learn.programming.battleoftheimmortals.utility.AccountObject
import learn.programming.battleoftheimmortals.utility.FightSimulator
import learn.programming.battleoftheimmortals.view.ItemIcon
import java.util.*

class FightActivity : AppCompatActivity() {
    lateinit var contestantTop: Actor
    lateinit var contestantBottom: Actor
    lateinit var turnState: TurnState

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fight)
        setupContestants()
        layoutSetup()
        turnState = TurnState.A
        timer.start()

        // Normal hit for top
        champ1AttackBtn.setOnClickListener {
            if (turnState == TurnState.A && contestantTop.isDead() && contestantBottom.isDead()) {
                // Fight logic
                FightSimulator.simulateFight(FightActivity(), contestantTop, contestantBottom, weapon2IV, testTV2, NORMAL_HIT, hpBar2)
                // Change turn state
                turnState = TurnState.B
                // Reset textview for timer and update contestant hp if hp<0
                updateTV(hPTV2, contestantBottom)
                // Updating progress bar
                addAbility(abilityPB, contestantBottom)
                updateFrameColor(contestant2IV, contestant1IV, contestantBottom)
                // Animations
                getAnimationFor(contestantTop, weapon2IV, testTV2)
            }
        }
        // Normal hit for bottom
        champ2AttackBtn.setOnClickListener {
            if (turnState == TurnState.B && contestantTop.isDead() && contestantBottom.isDead()) {
                // Fight logic
                FightSimulator.simulateFight(FightActivity(), contestantBottom, contestantTop, weapon1IV, testTV, NORMAL_HIT, hpBar)
                // Change turn state
                turnState = TurnState.A
                // Reset textview for timer and update contestant hp if hp<0
                updateTV(hPTV, contestantTop)
                // Updating progress bar
                addAbility(abilityPB2, contestantTop)
                updateFrameColor(contestant1IV, contestant2IV, contestantTop)
                // Animations
                getAnimationFor(contestantBottom, weapon1IV, testTV)
            }
        }
        // Ability hit for top
        contestant1IV.setOnClickListener {
            if (turnState == TurnState.A) {
                if (contestantTop.abilityPower == 100) {
                    contestantTop.abilityPower = 0
                    abilityPB2.progress = contestantTop.abilityPower
                    // Fight logic
                    FightSimulator.simulateFight(FightActivity(), contestantTop, contestantBottom, weapon2IV, testTV2, SKILL, hpBar2)
                    // Change turn state
                    turnState = TurnState.B
                    // Reset textview for timer and update contestant hp if hp<0
                    updateTV(hPTV2, contestantBottom)
                    // Updating progress bar
                    addAbility(abilityPB, contestantBottom)
                    updateFrameColor(contestant2IV, contestant1IV, contestantBottom)
                    // Animations
                    getAnimationFor(contestantTop, weapon2IV, testTV2)

                }
            }
        }
        // Ability hit for bottom
        contestant2IV.setOnClickListener {
            if (turnState == TurnState.B) {
                if (contestantBottom.abilityPower == 100) {
                    contestantBottom.abilityPower = 0
                    abilityPB.progress = contestantBottom.abilityPower
                    // Fight logic
                    FightSimulator.simulateFight(FightActivity(), contestantBottom, contestantTop, weapon1IV, testTV, SKILL, hpBar)
                    // Change turn state
                    turnState = TurnState.A
                    // Reset textview for timer and update contestant hp if hp<0
                    updateTV(hPTV, contestantTop)
                    // Updating progress bar
                    addAbility(abilityPB2, contestantTop)
                    updateFrameColor(contestant1IV, contestant2IV, contestantTop)
                    // Animations
                    getAnimationFor(contestantBottom, weapon1IV, testTV)

                }
            }
        }
    }

    // LAYOUT SETUP START

    fun layoutSetup() {
        contestant1IV.setImageResource(contestantTop.profession.pic)
        contestant2IV.setImageResource(contestantBottom.profession.pic)
        updateWeapons(contestantTop, leftWepTopII, rightWepTopII)
        updateWeapons(contestantBottom, rightWepBottomII, leftWepBottomII)
        setupHpAndAbility(contestantTop, hpBar, hPTV, abilityPB2)
        setupHpAndAbility(contestantBottom, hpBar2, hPTV2, abilityPB)
        contestantBottom.abilityPower = 40
        contestantTop.abilityPower = 0
        updateFrameColor(contestant1IV, contestant2IV, contestantTop)
    }
    fun setupHpAndAbility(contestant: Actor, barHP: ProgressBar, hpTV: TextView, apBar: ProgressBar) {
        contestant.hitPoints.value = contestant.maxHitPoints.value
        hpTV.setText(contestant.hitPoints.value.toString())
        barHP.progress = contestant.hitPoints.value / (contestant.maxHitPoints.value / 100)
    }
    fun updateWeapons(champ: Actor, itemIcon1: ItemIcon, itemIcon2: ItemIcon) {
        if (champ.weapon1.slotType == 1) {
            itemIcon1.updateView(champ.weapon1)
            itemIcon2.updateView(champ.weapon2)
        } else if (champ.weapon1.slotType == 2) {
            itemIcon1.updateView(champ.weapon1)
            itemIcon2.visibility = View.GONE
        } else {
            itemIcon1.visibility = View.GONE
            itemIcon2.visibility = View.GONE
        }
    }
    // Update Frame Color when TurnState is changed
    private fun updateFrameColor(iv: CircleImageView, iv2: CircleImageView, cont: Actor) {
        iv.borderWidth = 12
        iv.borderColor = Color.parseColor("#DDF7CE3A")
        iv2.borderWidth = 5
        iv2.borderColor = Color.parseColor("#63F7CE3A")
        if (cont.abilityPower == 100) {
            iv.borderWidth = 18
            iv.borderColor = Color.parseColor("#ff0000")
        }
    }
    // Adding ability on receiving damage
    private fun addAbility(bar: ProgressBar, contestant: Actor) {
        if (contestant.abilityPower <= 80) {
            contestant.abilityPower += 20
            bar.progress = contestant.abilityPower
        } else {
            bar.progress = bar.max
        }
    }
    private fun setupContestants() {
        val ctID = intent.extras?.getInt("ctID") ?: return
        val cbID = intent.extras?.getInt("cbID") ?: return

        contestantTop = AccountObject.currentAccount!!.champions.find { it.id == ctID } ?: return
        contestantBottom = AccountObject.currentAccount!!.champions.find { it.id == cbID } ?: return
    }

    // LAYOUT SETUP END

    enum class TurnState {
        A,
        B
    }

    enum class HitType {
        NORMAL_HIT,
        SKILL
    }

    fun changeFragmentTo(fragment: Fragment) {
        supportFragmentManager
            .beginTransaction()
            .addToBackStack(fragment.javaClass.name)
            .replace(R.id.fragmentHolder, fragment)
            .commit()
    }

    val timer = object : CountDownTimer(17000, 1000) {
        override fun onTick(millisUntilFinished: Long) {
            timerTV.setText("${(millisUntilFinished / 1000).toInt() - 1} s")
            if (contestantTop.isDead() == false || contestantBottom.isDead() == false) {
                timerTV.setText("FIGHT ENDED")
                cancel()
            } else if ((millisUntilFinished / 1000).toInt() == 6) {
                timerTV.setTextColor(Color.parseColor("#ff0000"))
                timerTV.textSize = 35f
            } else if ((millisUntilFinished / 1000).toInt() == 1) {
                timerTV.setText("ENEMY TURN        ")
            }
        }

        override fun onFinish() {
            timerTV.setText("")
            if (turnState == TurnState.A) {
                turnState = TurnState.B
                updateFrameColor(contestant2IV, contestant1IV, contestantBottom)
            } else {
                turnState = TurnState.A
                updateFrameColor(contestant1IV, contestant2IV, contestantTop)
            }
            timerTV.setTextColor(Color.parseColor("#DDF7CE3A"))
            timerTV.textSize = 24f
            start()
        }
    }

    fun getAnimationFor(contestant: Actor, wep: ImageView, dmg: TextView) {
       /* when (contestant.profession) {
            Profession.GLADIATOR -> {
                contestant.swordHitAnimation(weapon1IV)
            }
            Profession.ARCHER -> {
                wep.setImageResource(R.drawable.archer_arrow)
                wep.scaleX = 1.5f
                wep.scaleY = 2.5f
                if (contestant == contestantTop){
                    wep.rotationX = 180f
                    contestant.arrowHitAnimation(wep)
                }else {
                    contestant.arrowHitAnimation2(wep)
                }
            }
            Profession.ASSASSIN -> {
                wep.setImageResource(R.drawable.assasin_daggers)
                wep.scaleX = 2.5f
                wep.scaleY = 2.5f
                if (contestant == contestantTop){
                    contestant.daggerHitAnimation(wep)
                }else {
                    contestant.daggerHitAnimation2(wep)
                }
            }
            Profession.KNIGHT -> {
                wep.setImageResource(R.drawable.knight_sword)
                wep.scaleX = 1.5f
                wep.scaleY = 1.5f
                if (contestant == contestantTop){
                    contestant.greatSwordAnimation(wep)
                }else {
                    contestant.greatSwordAnimation2(wep)
                }
            }
            Profession.MAGE -> {
                wep.setImageResource(R.drawable.mage_attack)
                wep.scaleY = 2.0f
                wep.scaleX = 2.0f
                wep.rotationX = 180f
                if (contestant == contestantTop){
                    contestant.fireHitAnimation(wep)
                }else {
                    contestant.fireHitAnimation2(wep)
                }
            }
            Profession.PRIEST -> {
                wep.setImageResource(R.drawable.priest_attack)
                wep.scaleX = 1.5f
                wep.scaleY = 1.5f
                wep.rotationX = 180f
                if (contestant == contestantTop){
                    contestant.fireHitAnimation(wep)
                }else {
                    contestant.fireHitAnimation2(wep)
                }
            }
        }*/
        Timer().schedule(object : TimerTask() {
            override fun run() {
                this@FightActivity.runOnUiThread(java.lang.Runnable {
                    wep.visibility = View.INVISIBLE
                    dmg.text = ""
                })
            }
        }, 1000)
        timer.start()
    }

    fun updateTV(hp: TextView, contestant: Actor) {

        timerTV.setTextColor(Color.parseColor("#DDF7CE3A"))
        timerTV.textSize = 24f
        if (contestant.hitPoints.value <= 0) {
            hp.setText("0")
            hp.setTextColor(Color.parseColor("#ff0000"))
        } else {
            hp.setText(contestant.hitPoints.value.toString())
        }
    }

}