package learn.programming.battleoftheimmortals.database.model.item

import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.database.model.account.Stat

data class Item(
    val name: String,
    val id: String,
    val type: Type,
    val goldValue: Int,
    val tier: Tier,
    val icon: Int,
    val stats: MutableList<Stat> = mutableListOf(),
    val slotType: Int? = null,
    val efects: List<ItemEffect>? = null
) {
    var dbID: String = ""

    enum class Type(val icon: Int = R.drawable.ico_default) {
        RING(R.drawable.ico_ring),
        BELT(R.drawable.ico_belt),
        EARRING(R.drawable.ico_earing),
        GLOVES(R.drawable.ico_gloves),
        CHESTARMOR(R.drawable.ico_chest),
        BOOTS(R.drawable.ico_boots),
        HELMET(R.drawable.ico_helmet),
        NECKLACE(R.drawable.ico_necklace),
        WEAPON(R.drawable.ico_weapon)
    }

    enum class Tier(val color: String) {
        BASIC("#555555"),
        NOBLE("#00ff00"),
        RARE("#0000ff"),
        EPIC("#c11df2"),
        HEROIC("#ff0000"),
        LEGENDARY("#fa8e3c")
    }

    fun statsToString(): String {
        var string = ""
        stats.forEach {
            string += "${it.type.name}: ${it.value}\n"
        }

        return string
    }

    fun isEmpty(): Boolean = id == "${this.type.name}0"

    override fun equals(other: Any?): Boolean {
        return (other as Item).id == id
    }
}