package learn.programming.battleoftheimmortals.database.model.account

import androidx.room.*
import learn.programming.battleoftheimmortals.database.model.actor.Champion

@Entity(tableName = "Account")
class Account {
    @PrimaryKey(autoGenerate = true)
    var id: Int = 0

    var userName: String? = null
    var password: String? = null
    var gold: Int? = null

    @ColumnInfo(defaultValue = "0")
    var currentTowerFloor: Int = 0

    @ColumnInfo(defaultValue = "0")
    var maxReachedTowerFloor: Int = 0

    constructor(userName: String,
                password: String){
        this.userName = userName
        this.password = password
    }

    class AccountData{
        @Embedded
        var instance: Account? = null


        @Relation(entity = Champion::class, entityColumn = "accountId", parentColumn = "id")
        var champions: MutableList<Champion> = mutableListOf()
    }
}
