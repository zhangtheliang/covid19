package learn.programming.battleoftheimmortals.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.tower_champion_spinner.view.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.database.model.actor.Champion

class TowerChampionSpinner(context: Context,list: List<Champion>):ArrayAdapter<Champion>(context,R.layout.tower_champion_spinner,list) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {


        var view = convertView
        if (view == null){
            view = LayoutInflater.from(context).inflate(R.layout.tower_champion_spinner,null,false)
        }

        val currentItem = getItem(position)
        val champ = currentItem as Champion
        val hpPercentage = champ.maxHitPoints.value / 100

        view?.champIconIV?.setImageResource(champ.profession.icon)
        view?.champNameTV?.text = "${champ.name}"
        view?.champHealthPB?.progress = champ.hitPoints.value / hpPercentage
        view?.champArmorTV?.text = "Armor:${champ.armor.value}"
        view?.champDamageTV?.text = "DMG:${champ.damage.value}"
        view?.champAccuracyTV?.text = "Accuracy:${champ.accuracy.value}"
        view?.champEvasionTV?.text = "Evasion:${champ.evasion.value}"

       return view!!
    }

    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
        return getView(position, convertView, parent)
    }
}