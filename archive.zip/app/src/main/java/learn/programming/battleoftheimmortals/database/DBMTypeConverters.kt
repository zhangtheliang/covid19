package learn.programming.battleoftheimmortals.database

import androidx.room.TypeConverter
import learn.programming.battleoftheimmortals.database.model.account.Stat

class DBMTypeConverters{
    @TypeConverter
    fun statToString(stat: Stat) : String {
        return stat.toString()
    }

    @TypeConverter
    fun stringToStat(str:String) : Stat?{
        return Stat(str)
    }
}