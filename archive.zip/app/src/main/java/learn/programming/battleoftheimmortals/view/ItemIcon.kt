package learn.programming.battleoftheimmortals.view

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PorterDuff
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.FrameLayout
import kotlinx.android.synthetic.main.item_icon_layout.view.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.database.model.item.Item

class ItemIcon(context: Context, attrs: AttributeSet) : FrameLayout(context, attrs) {
    lateinit var item: Item
    init{
        LayoutInflater.from(context).inflate(R.layout.item_icon_layout, this, true)
    }

    fun updateView(item: Item){
        this.item = item
        frameIV.imageTintList = ColorStateList.valueOf(Color.parseColor(item.tier.color))
        frameIV.imageTintMode = PorterDuff.Mode.SRC_ATOP

        srcIV.setImageResource(item.icon)
    }

    override fun setVisibility(visibility: Int) {
        frameIV.visibility = visibility
        srcIV.visibility = visibility
        super.setVisibility(visibility)
    }
}