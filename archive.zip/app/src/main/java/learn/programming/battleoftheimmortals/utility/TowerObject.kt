package learn.programming.battleoftheimmortals.utility

import learn.programming.battleoftheimmortals.database.DBM
import learn.programming.battleoftheimmortals.database.model.tower.Floor

object TowerObject {
    val floors: List<Floor> = listOf(
        Floor(
            0,
            "Level 1",
            listOf(
                MonsterObject.getMonsterByID("2"),
                MonsterObject.getMonsterByID("1")
            ),
            listOf()
        ),
        Floor(
            1,
            "Level 2",
            listOf(
                MonsterObject.getMonsterByID("3"),
                MonsterObject.getMonsterByID("4")
            ),
            listOf()
        ),
        Floor(
            2,
            "Level 3",
            listOf(
                MonsterObject.getMonsterByID("7"),
                MonsterObject.getMonsterByID("5"),
                MonsterObject.getMonsterByID("21")
                ),
            listOf()

        ),
        Floor(
            3,
            "Level 4",
            listOf(
                MonsterObject.getMonsterByID("9"),
                MonsterObject.getMonsterByID("11"),
                MonsterObject.getMonsterByID("23")
            ),
            listOf()

        ),
        Floor(
            4,
            "Level 5",
            listOf(
                MonsterObject.getMonsterByID("6"),
                MonsterObject.getMonsterByID("31"),
                MonsterObject.getMonsterByID("25")
            ),
            listOf()

        ),
        Floor(
            5,
            "Level 6",
            listOf(
                MonsterObject.getMonsterByID("22"),
                MonsterObject.getMonsterByID("31"),
                MonsterObject.getMonsterByID("40")
            ),
            listOf()
        ),
        Floor(
            6,
            "Level 7",
            listOf(
                MonsterObject.getMonsterByID("17"),
                MonsterObject.getMonsterByID("18"),
                MonsterObject.getMonsterByID("29"),
                MonsterObject.getMonsterByID("41")
            ),
            listOf()
        ),
        Floor(
            7,
            "Level 8",
            listOf(
                MonsterObject.getMonsterByID("21"),
                MonsterObject.getMonsterByID("22"),
                MonsterObject.getMonsterByID("23"),
                MonsterObject.getMonsterByID("45")
            ),
            listOf()
        ),
        Floor(
            8,
            "Level 9",
            listOf(
                MonsterObject.getMonsterByID("17"),
                MonsterObject.getMonsterByID("13"),
                MonsterObject.getMonsterByID("26"),
                MonsterObject.getMonsterByID("31"),
                MonsterObject.getMonsterByID("46")
            ),
            listOf()
        ),
        Floor(
            9,
            "Level 10",
            listOf(
                MonsterObject.getMonsterByID("39"),
                MonsterObject.getMonsterByID("29"),
                MonsterObject.getMonsterByID("44"),
                MonsterObject.getMonsterByID("43"),
                MonsterObject.getMonsterByID("5")
            ),
            listOf()
        ),
        Floor(
            10,
            "Level 11",
            listOf(
                MonsterObject.getMonsterByID("17"),
                MonsterObject.getMonsterByID("18"),
                MonsterObject.getMonsterByID("33"),
                MonsterObject.getMonsterByID("49"),
                MonsterObject.getMonsterByID("41")
            ),
            listOf()
        ),
        Floor(
            11,
            "Level 12",
            listOf(
                MonsterObject.getMonsterByID("23"),
                MonsterObject.getMonsterByID("35"),
                MonsterObject.getMonsterByID("37"),
                MonsterObject.getMonsterByID("42"),
                MonsterObject.getMonsterByID("44")
            ),
            listOf()
        ),
        Floor(
            12,
            "Level 13",
            listOf(
                MonsterObject.getMonsterByID("35"),
                MonsterObject.getMonsterByID("37"),
                MonsterObject.getMonsterByID("42"),
                MonsterObject.getMonsterByID("46"),
                MonsterObject.getMonsterByID("48")
            ),
            listOf()
        ),
        Floor(
            13,
            "Level 14",
            listOf(
                MonsterObject.getMonsterByID("42"),
                MonsterObject.getMonsterByID("44"),
                MonsterObject.getMonsterByID("43"),
                MonsterObject.getMonsterByID("41"),
                MonsterObject.getMonsterByID("47")
            ),
            listOf()
        ),
        Floor(
            14,
            "Level 15",
            listOf(
                MonsterObject.getMonsterByID("45"),
                MonsterObject.getMonsterByID("43"),
                MonsterObject.getMonsterByID("48"),
                MonsterObject.getMonsterByID("51"),
                MonsterObject.getMonsterByID("53")
            ),
            listOf()
        ),
        Floor(
            15,
            "Level 16",
            listOf(
                MonsterObject.getMonsterByID("45"),
                MonsterObject.getMonsterByID("48"),
                MonsterObject.getMonsterByID("52"),
                MonsterObject.getMonsterByID("54"),
                MonsterObject.getMonsterByID("57")
            ),
            listOf()
        ),
        Floor(
            16,
            "Level 17",
            listOf(
                MonsterObject.getMonsterByID("59"),
                MonsterObject.getMonsterByID("58"),
                MonsterObject.getMonsterByID("52"),
                MonsterObject.getMonsterByID("54"),
                MonsterObject.getMonsterByID("51")
            ),
            listOf()
        ),
        Floor(
            17,
            "Level 18",
            listOf(
                MonsterObject.getMonsterByID("55"),
                MonsterObject.getMonsterByID("53"),
                MonsterObject.getMonsterByID("58"),
                MonsterObject.getMonsterByID("61"),
                MonsterObject.getMonsterByID("64")
            ),
            listOf()
        ),
        Floor(
            18,
            "Level 19",
            listOf(
                MonsterObject.getMonsterByID("51"),
                MonsterObject.getMonsterByID("50"),
                MonsterObject.getMonsterByID("61"),
                MonsterObject.getMonsterByID("63"),
                MonsterObject.getMonsterByID("65")
            ),
            listOf()
        ),
        Floor(
            19,
            "Level 20",
            listOf(
                MonsterObject.getMonsterByID("64"),
                MonsterObject.getMonsterByID("66"),
                MonsterObject.getMonsterByID("67"),
                MonsterObject.getMonsterByID("61"),
                MonsterObject.getMonsterByID("62")
            ),
            listOf()
        )
    )

    var currentFloor: Floor = getCurrentFloorFromDB()

    private fun getCurrentFloorFromDB(): Floor {
        val acc = DBM.getSharedInstance().accountDao().getAll().first()
        val cfID = acc.instance!!.currentTowerFloor
        return floors.find { it.ID == cfID } ?: floors[0]
    }
}