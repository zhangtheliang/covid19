package learn.programming.battleoftheimmortals.fragment.main


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.fragment_options.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.activity.MainActivity
import learn.programming.battleoftheimmortals.fragment.options.*

/**
 * A simple [Fragment] subclass.
 */
class OptionsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_options, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        creditsBtn.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(CreditsFragment())
        }

        deleteAccountBtn.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(DeleteAccountFragment())
        }

        changePasswordBtn.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(ChangePasswordFragment())
        }

        serverInfoBtn.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(ServerStatusFragment())
        }

        contactSupportBtn.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(ContactSupportFragment())
        }
    }
}
