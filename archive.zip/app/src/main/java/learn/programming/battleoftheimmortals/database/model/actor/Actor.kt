package learn.programming.battleoftheimmortals.database.model.actor

import android.animation.ObjectAnimator
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.LinearInterpolator
import androidx.interpolator.view.animation.FastOutSlowInInterpolator
import androidx.room.Ignore
import androidx.room.PrimaryKey
import learn.programming.battleoftheimmortals.database.model.account.Stat
import learn.programming.battleoftheimmortals.database.model.item.Item
import learn.programming.battleoftheimmortals.utility.ItemObject
import kotlin.math.roundToInt

// das ist un POJO
abstract class Actor(
    var raceId: Int,
    var professionId: Int,
    var name: String
) {
    @PrimaryKey(autoGenerate = true)
    var id: Int = 0

    @Ignore
    var race: Race

    @Ignore
    var profession: Profession

    @Ignore
    var abilityPower: Int = 0

    @Ignore
    var maxAbilityPower: Int = 100

    var maxHitPoints: Stat =
        Stat(
            Stat.StatType.HIT_POINTS,
            0
        )
    var hitPoints: Stat =
        Stat(
            Stat.StatType.HIT_POINTS,
            0
        )
    var armor: Stat =
        Stat(
            Stat.StatType.ARMOR,
            0
        )
    var damage: Stat =
        Stat(
            Stat.StatType.DAMAGE,
            0
        )
    var heal: Stat =
        Stat(
            Stat.StatType.HEAL,
            0
        )
    var accuracy: Stat =
        Stat(
            Stat.StatType.ACCURACY,
            0
        )
    var critChance: Stat =
        Stat(
            Stat.StatType.CRIT_RATE,
            0
        )
    var evasion: Stat =
        Stat(
            Stat.StatType.EVASION,
            0
        )
    var attackSpeed = Stat(
        Stat.StatType.ATTACK_SPEED,
        0
    )

    //BASE STATS
    @Ignore
    var strenght: Stat =
        Stat(
            Stat.StatType.STRENGTH,
            0
        )
    @Ignore
    var agility: Stat =
        Stat(
            Stat.StatType.AGILITY,
            0
        )
    @Ignore
    var intellect: Stat =
        Stat(
            Stat.StatType.INTELLECT,
            0
        )
    @Ignore
    var wisdom: Stat =
        Stat(
            Stat.StatType.WISDOM,
            0
        )

    enum class SlotId(val id: Int){
        INVENTORY(0),
        HELMET(1),
        EARRING_LEFT(2),
        EARRING_RIGHT(3),
        NECKLACE(4),
        CHEST(5),
        GLOVES(6),
        RING_LEFT(7),
        RING_RIGHT(8),
        BELT(9),
        BOOTS(10),
        WEAPON_LEFT(11),
        WEAPON_RIGHT(12)
    }
    //item slots
    @Ignore
    var helmet: Item = ItemObject.helmets[0]
    @Ignore
    var earring1: Item = ItemObject.earrings[0]
    @Ignore
    var earring2: Item = ItemObject.earrings[0]
    @Ignore
    var necklace: Item = ItemObject.necklaces[0]
    @Ignore
    var chestarmor: Item = ItemObject.chest[0]
    @Ignore
    var gloves: Item = ItemObject.gloves[0]
    @Ignore
    var ring1: Item = ItemObject.rings[0]
    @Ignore
    var ring2: Item = ItemObject.rings[0]
    @Ignore
    var belt: Item = ItemObject.belts[0]
    @Ignore
    var boots: Item = ItemObject.boots[0]
    @Ignore
    var weapon1: Item = ItemObject.weapon[0]
    @Ignore
    var weapon2: Item = ItemObject.weapon[0]

    init {
        race =
            Race.getById(this.raceId)
        this.profession =
            Profession.getById(this.professionId)
        updateAllStats()
    }

    fun updateAllStats() {
        resetAllStats()
        addItemsToStats()
        calculateStatsFromRaceAndProfession()
    }

    fun getAllEquippedItems(): List<Item> {
        val list = mutableListOf<Item>()
        if (!this.earring1.isEmpty()) list.add(earring1)
        if (!this.earring2.isEmpty()) list.add(earring2)
        if (!this.helmet.isEmpty()) list.add(helmet)
        if (!this.necklace.isEmpty()) list.add(necklace)
        if (!this.belt.isEmpty()) list.add(belt)
        if (!this.ring1.isEmpty()) list.add(ring1)
        if (!this.ring2.isEmpty()) list.add(ring2)
        if (!this.chestarmor.isEmpty()) list.add(chestarmor)
        if (!this.boots.isEmpty()) list.add(boots)
        if (!this.weapon1.isEmpty()) list.add(weapon1)
        if (!this.weapon2.isEmpty()) list.add(weapon2)
        if (!this.gloves.isEmpty()) list.add(gloves)
        return list
    }

    fun resetAllStats() {
        this.maxHitPoints.value = 0
        this.hitPoints.value = 0
        this.armor.value = 0
        this.heal.value = 0
        this.damage.value = 0

        this.strenght.value = 0
        this.wisdom.value = 0
        this.agility.value = 0
        this.intellect.value = 0
        this.accuracy.value = 0
        this.critChance.value = 0
        this.evasion.value = 0
        this.attackSpeed.value = 0
    }

    fun addItemsToStats() {
        getAllEquippedItems().forEach {
            calculateStatsForItem(it)
        }
    }

    private fun calculateStatsForItem(item: Item) {
        item.stats.forEach { stat ->
            when (stat.type) {
                Stat.StatType.WISDOM -> this.wisdom.value += stat.value
                Stat.StatType.STRENGTH -> this.strenght.value += stat.value
                Stat.StatType.AGILITY -> this.agility.value += stat.value
                Stat.StatType.INTELLECT -> this.intellect.value += stat.value
                Stat.StatType.CRIT_RATE -> this.critChance.value += stat.value
                Stat.StatType.ACCURACY -> this.accuracy.value += stat.value
                Stat.StatType.HIT_POINTS -> {
                    this.maxHitPoints.value += stat.value
                }
                Stat.StatType.ARMOR -> this.armor.value += stat.value
                Stat.StatType.DAMAGE -> this.damage.value += stat.value
                Stat.StatType.HEAL -> this.heal.value += stat.value
                Stat.StatType.EVASION -> this.evasion.value += stat.value
                Stat.StatType.ATTACK_SPEED -> this.attackSpeed.value += stat.value
            }
        }
    }
    fun calculateStatsFromRaceAndProfession() {
        this.maxHitPoints.value += this.profession.hitPoints + race.strenght
        this.hitPoints.value = this.maxHitPoints.value
        this.armor.value += this.profession.armor + (this.wisdom.value * 0.15).toInt() + (this.intellect.value * 0.1).toInt() + (this.agility.value * 0.15).toInt()
        this.heal.value += this.profession.heal
        this.damage.value += this.profession.damage + getDamageFromStats()

        this.strenght.value += race.strenght
        this.wisdom.value += race.wisdom
        this.agility.value += race.agility
        this.intellect.value += race.intellect
        this.accuracy.value += this.profession.accuracy + this.race.agility
        this.critChance.value += this.profession.critChance
        this.evasion.value += this.profession.evasion + (this.agility.value * 0.05).toInt()
        this.attackSpeed.value += this.profession.id
    }

    private fun getDamageFromStats(): Int {
        return when (profession) {
            Profession.GLADIATOR -> {
                (strenght.value * 1) + (intellect.value * 0.1) + (agility.value * 0.4)
            }
            Profession.KNIGHT -> {
                (strenght.value * 0.8) + (intellect.value * 0.2) + (agility.value * 0.3) + (wisdom.value * 0.1)
            }
            Profession.MAGE -> {
                (strenght.value * 0.2) + (intellect.value * 1.2) + (agility.value * 0.2)
            }
            Profession.ASSASSIN -> {
                (strenght.value * 0.6) + (intellect.value * 0.4) + (agility.value * 0.8)
            }
            Profession.ARCHER -> {
                (strenght.value * 0.4) + (intellect.value * 0.2) + (agility.value * 1.1)
            }
            Profession.PRIEST -> {
                (strenght.value * 0.6) + (intellect.value * 0.9) + (agility.value * 0.4) + (wisdom.value * 0.3)
            }
        }.roundToInt()
    }

    fun takeDamage(damage: Int): Int {
        val armorPercentage = (1 - (armor.value.toDouble() / 100))
        val damageTaken = (damage * armorPercentage).toInt()
        hitPoints.value -= damageTaken
        if (this.profession == Profession.PRIEST){
            hitPoints.value += heal.value
        }
        return damageTaken
    }

    fun getDamangeOnHit(enemy: Actor): Int {
        var damage = damage.value
        val ELT = enemy.armor.value * 0.5f
        val EUT = enemy.armor.value * 2f
        val EDT = EUT - ELT
        val H = damage - ELT
        if (H < 0){
            return 0
        }
        return ((100/EDT) * H).toInt()
    }

    fun getHitChance(enemy: Actor): Float {
        var accuracy = accuracy.value
        val ELT = enemy.evasion.value * 0.65f
        val EUT = enemy.evasion.value * 1.5f
        val EDT = EUT - ELT
        val H = accuracy - ELT

        return (100/EDT) * H
    }

    fun isDead() : Boolean = hitPoints.value > 0

     fun swordHitAnimation(view: View) {
        val swordHit = ObjectAnimator.ofFloat(view, View.ROTATION,10f,-60f)

        swordHit.duration = 700
        swordHit.repeatMode = ObjectAnimator.RESTART
        swordHit.interpolator = FastOutSlowInInterpolator()
        swordHit.start()
    }

    fun arrowHitAnimation(view:View){
        val arrowHit = ObjectAnimator.ofFloat(view,View.TRANSLATION_Y,-1000f,150f)

        arrowHit.duration = 600
        arrowHit.repeatMode = ObjectAnimator.RESTART
        arrowHit.interpolator = AccelerateInterpolator(2.5f)
        arrowHit.start()
    }

    fun arrowHitAnimation2(view:View){
        val arrowHit = ObjectAnimator.ofFloat(view,View.TRANSLATION_Y,1000f,-150f)

        arrowHit.duration = 600
        arrowHit.repeatMode = ObjectAnimator.RESTART
        arrowHit.interpolator = AccelerateInterpolator(2.5f)
        arrowHit.start()
    }

    fun daggerHitAnimation(view:View){
        val daggerHit = ObjectAnimator.ofFloat(view,View.TRANSLATION_Y,0f,150f)

        daggerHit.duration = 350
        daggerHit.repeatMode = ObjectAnimator.RESTART
        daggerHit.interpolator = FastOutSlowInInterpolator()
        daggerHit.start()
    }

    fun daggerHitAnimation2(view:View){
        val daggerHit = ObjectAnimator.ofFloat(view,View.TRANSLATION_Y,0f,-150f)

        daggerHit.duration = 350
        daggerHit.repeatMode = ObjectAnimator.RESTART
        daggerHit.interpolator = FastOutSlowInInterpolator()
        daggerHit.start()
    }

    fun greatSwordAnimation(view: View){
        val swordHit = ObjectAnimator.ofFloat(view,View.ROTATION,-170f,-100f)

        swordHit.duration = 500
        swordHit.repeatMode = ObjectAnimator.RESTART
        swordHit.interpolator = FastOutSlowInInterpolator()
        swordHit.start()
    }

    fun greatSwordAnimation2(view: View){
        val swordHit = ObjectAnimator.ofFloat(view,View.ROTATION,10f,80f)

        swordHit.duration = 500
        swordHit.repeatMode = ObjectAnimator.RESTART
        swordHit.interpolator = FastOutSlowInInterpolator()
        swordHit.start()
    }

    fun fireHitAnimation(view: View) {
        val fireHit = ObjectAnimator.ofFloat(view,View.TRANSLATION_Y,1200f,-150f)

        fireHit.duration = 800
        fireHit.repeatMode = ObjectAnimator.RESTART
        fireHit.interpolator = LinearInterpolator()
        fireHit.start()
    }
    fun fireHitAnimation2(view: View) {
        val fireHit = ObjectAnimator.ofFloat(view,View.TRANSLATION_Y,-1200f,150f)

        fireHit.duration = 800
        fireHit.repeatMode = ObjectAnimator.RESTART
        fireHit.interpolator = LinearInterpolator()
        fireHit.start()
    }
}