package learn.programming.battleoftheimmortals.fragment.options


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.fragment_delete_account.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.activity.MainActivity
import learn.programming.battleoftheimmortals.fragment.main.OptionsFragment
import learn.programming.battleoftheimmortals.utility.AccountObject

/**
 * A simple [Fragment] subclass.
 */
class DeleteAccountFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_delete_account, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        noBtn.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(OptionsFragment())
        }

        yesBtn.setOnClickListener {
            AccountObject.logOutAndDeleteAccount(this.context!!)
        }
    }

}
