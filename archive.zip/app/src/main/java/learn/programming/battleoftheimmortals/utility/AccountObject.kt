package learn.programming.battleoftheimmortals.utility

import android.content.Context
import android.content.Intent
import learn.programming.battleoftheimmortals.activity.LoginActivity
import learn.programming.battleoftheimmortals.database.DBM
import learn.programming.battleoftheimmortals.database.model.account.Account
import learn.programming.battleoftheimmortals.database.model.actor.Champion

object AccountObject {
    var currentAccount: Account.AccountData? = null

    fun validateLogin(username: String, password: String): Boolean {
        val loggedInAccount = DBM.getSharedInstance().accountDao().validateLoginCredentials(username, password)
        if (loggedInAccount != null) {
            currentAccount = loggedInAccount
            return true
        } else
            return false
    }

    fun validateRegister(username: String): Boolean {
        val existingUsername = DBM.getSharedInstance().accountDao().validateRegisterCredentials(username)
        if (existingUsername == null) {
            return true
        } else return false
    }
    fun validateCreateCharacter(name: String): Boolean {
        val existingName = DBM.getSharedInstance().championDao().validateCreateCharacterCredentials(name)
        if (existingName == null) {
            return true
        } else return false
    }

    fun addNewChampion(champion: Champion) {
        this.currentAccount?.champions?.add(champion)
    }

    fun logOutAndDeleteAccount(context: Context) {
        DBM.getSharedInstance().accountDao().delete(currentAccount?.instance ?: return)
        currentAccount = null
        val intent = Intent(context, LoginActivity::class.java)
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        context.startActivity(intent)
    }

}