package learn.programming.battleoftheimmortals.fragment.main.champion


import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.fragment_champion_create.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.activity.MainActivity
import learn.programming.battleoftheimmortals.adapter.CreateNewCharacterSpinnerAdapter
import learn.programming.battleoftheimmortals.database.DBM
import learn.programming.battleoftheimmortals.database.model.actor.Champion
import learn.programming.battleoftheimmortals.database.model.actor.Profession
import learn.programming.battleoftheimmortals.database.model.actor.Race
import learn.programming.battleoftheimmortals.utility.AccountObject

class CreateChampionFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_champion_create, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        createNewCharacterRaceSPINNER.adapter = CreateNewCharacterSpinnerAdapter(this.context!!, Race.values().filter { it.actorType == Race.ActorType.CHAMPION }.toList())
        createNewCharacterProfessionSPINNER.adapter = CreateNewCharacterSpinnerAdapter(this.context!!, Profession.values().toList())
        buttonFinishChampion.setOnClickListener {
            val race = createNewCharacterRaceSPINNER.selectedItem as Race
            val profession = createNewCharacterProfessionSPINNER.selectedItem as Profession
            var name = nameET.text.toString()
            val champ = Champion(
                AccountObject.currentAccount!!.instance!!.id,
                nameET.text.toString(),
                race.id,
                profession.id
            )
            nameET.setOnFocusChangeListener { v, hasFocus ->
                    nameET.setTextColor(Color.parseColor("#ff0000"))
            }
            if (AccountObject.validateCreateCharacter(name) == false){
                Toast.makeText(this.context, "Name already exists.", Toast.LENGTH_LONG).show()
                nameET.alpha = 0.5f
                return@setOnClickListener
            }
            if (name.length <= 2){
                Toast.makeText(this.context, "Name is too shorh.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            DBM.getSharedInstance().championDao().save(champ)
            AccountObject.addNewChampion(champ)
            (activity as MainActivity).changeFragmentTo(YourChampionsFragment())
        }
    }



}
