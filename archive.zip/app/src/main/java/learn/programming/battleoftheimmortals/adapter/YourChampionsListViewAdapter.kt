package learn.programming.battleoftheimmortals.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import kotlinx.android.synthetic.main.main_row.view.*
import learn.programming.battleoftheimmortals.R.layout
import learn.programming.battleoftheimmortals.activity.MainActivity
import learn.programming.battleoftheimmortals.database.DBM
import learn.programming.battleoftheimmortals.fragment.main.champion.InfoChampionFragment
import learn.programming.battleoftheimmortals.utility.AccountObject

class YourChampionsListViewAdapter(context: Context) : BaseAdapter() {
    val thisContext: Context

    init {
        thisContext = context
    }

    override fun getCount(): Int {
        return AccountObject.currentAccount!!.champions.size
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getItem(position: Int): Any {
        return ""
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {

        val champ = AccountObject.currentAccount!!.champions[position]
        val layoutInflater = LayoutInflater.from(thisContext)
        val mainRow = layoutInflater.inflate(layout.main_row, parent, false)
        mainRow.setOnClickListener {
            (thisContext as MainActivity).changeFragmentTo(InfoChampionFragment(champ))

            champ.updateAllStats()
        }
        mainRow.deleteBTN.setOnClickListener {
        DBM.getSharedInstance().championDao().remove(champ)
            AccountObject.currentAccount!!.champions.remove(champ)
            notifyDataSetChanged()
            champ.updateAllStats()
        }
        mainRow.champNameTV.text = champ.name
        mainRow.champProfessionTV.text = champ.profession.toString()
        mainRow.champRaceTV.text = champ.race.toString()
        mainRow.avatarIV.setImageResource(champ.profession.icon)
        return mainRow
    }
}