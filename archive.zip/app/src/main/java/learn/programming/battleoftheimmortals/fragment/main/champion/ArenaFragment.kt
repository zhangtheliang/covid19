package learn.programming.battleoftheimmortals.fragment.main.champion

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.Toast
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.fragment_arena.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.activity.FightActivity
import learn.programming.battleoftheimmortals.adapter.ChooseChampionSpinner
import learn.programming.battleoftheimmortals.database.model.actor.Champion
import learn.programming.battleoftheimmortals.utility.AccountObject


class ArenaFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_arena, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        var spinner1 = chooseChampionSPINNER
        var spinner2 = chooseChampionSPINNER2
        spinner1.adapter = ChooseChampionSpinner(this.context!!, AccountObject.currentAccount?.champions?.toList() ?: listOf())
        spinner2.adapter = ChooseChampionSpinner(this.context!!, AccountObject.currentAccount?.champions?.toList()?.reversed() ?: listOf())

        spinner1.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                val selectedItem = parent.getItemAtPosition(position) as Champion
                var champ = selectedItem
                champ.updateInventory()
                if (selectedItem == champ) {
                    statTV.setText("HP:${champ.hitPoints.value}  ARMOR:${champ.armor.value}  DMG:${champ.damage.value}")
                    subStatTV.setText("Acc:${champ.accuracy.value}  Crit:${champ.critChance.value}%  Evasion:${champ.evasion.value}\"")
                }
            } // to close the onItemSelected

            override fun onNothingSelected(parent: AdapterView<*>) {

            }
        }
        spinner2.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                val selectedItem = parent.getItemAtPosition(position) as Champion
                var champ = selectedItem
                champ.updateInventory()
                if (selectedItem == champ) {
                    stat2TV.setText("HP:${champ.hitPoints.value}  ARMOR:${champ.armor.value}  DMG:${champ.damage.value}")
                    subStat2TV.setText("Acc:${champ.accuracy.value}  Crit:${champ.critChance.value}%  Evasion:${champ.evasion.value}")
                }
            } // to close the onItemSelected

            override fun onNothingSelected(parent: AdapterView<*>) {

            }
        }

        vsIV.setImageResource(R.drawable.sword)
        choseChamp1TV.setText("Contestant 1")
        choseChamp2TV.setText("Contestant 2")
        vsIV.setOnClickListener {

            val c1 = chooseChampionSPINNER.selectedItem as Champion
            val c2 = chooseChampionSPINNER2.selectedItem as Champion
            if (c1 == c2){
                Toast.makeText(this.context!!,"Choose different champions", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val intent = Intent(this.context, FightActivity::class.java)
            val bundle = Bundle()
            bundle.putInt("cbID", c2.id)
            bundle.putInt("ctID", c1.id)
            intent.putExtras(bundle)
            startActivity(intent)
        }

        //arenaRL.setBackgroundResource(R.drawable.photo_arena2)
    }
        fun resetStats(){

        }
}

