package learn.programming.battleoftheimmortals.fragment.main.champion


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.fragment_champion_info.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.activity.MainActivity
import learn.programming.battleoftheimmortals.database.model.actor.Champion
import learn.programming.battleoftheimmortals.fragment.main.shop.ItemShopFragment

class InfoChampionFragment(val champion: Champion) : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_champion_info, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        champion.updateInventory()
        updateValues()

        itemsBtn.setOnClickListener {
            champion.updateAllStats()
            updateValues()
            (activity as MainActivity).changeFragmentTo(ChampionItemFragment(champion))
        }
        shopBtn.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(ItemShopFragment(champion))
        }
        characterBtn.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(EquipedItemsFragment(champion))
        }
    }

    fun updateValues(){
        championNameTV.setText(champion.name)
        championProffesionTV.setText(champion.profession.toString())
        championRaceTV.setText(champion.race.toString())
        championHitPointsTV.setText(champion.hitPoints.value.toString())
        championArmourTV.setText(champion.armor.value.toString())
        championDamageTV.setText(champion.damage.value.toString())
        championHealTV.setText(champion.heal.value.toString())
        championAccuracyTV.setText("${champion.accuracy.value}")
        championCritTV.setText("${champion.critChance.value}%")
        evasionTV.setText("${champion.evasion.value}")
    }
}
