package learn.programming.battleoftheimmortals.database.dao

import androidx.room.*
import learn.programming.battleoftheimmortals.database.model.account.Account
import learn.programming.battleoftheimmortals.utility.AccountObject
import kotlin.reflect.KClass

@Dao
interface AccountDao{
    @Transaction
    @Query("SELECT * FROM Account")
    fun getAll() : List<Account.AccountData>

    @Transaction
    @Query("SELECT * FROM Account WHERE userName=:username AND password=:password LIMIT 1")
    fun validateLoginCredentials(username: String, password: String) : Account.AccountData?

    @Transaction
    @Query("SELECT * FROM Account WHERE userName=:username LIMIT 1")
    fun validateRegisterCredentials(username: String) : Account.AccountData?

    @Insert
    fun save(account: Account)

    @Delete
    fun delete(account: Account)

    @Query("UPDATE Account SET password = :password WHERE id = :accID")
    fun changePassword(password: String, accID:Int)
}
