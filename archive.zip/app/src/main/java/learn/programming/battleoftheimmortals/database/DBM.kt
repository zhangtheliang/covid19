package learn.programming.battleoftheimmortals.database

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import learn.programming.battleoftheimmortals.App
import learn.programming.battleoftheimmortals.database.dao.AccountDao
import learn.programming.battleoftheimmortals.database.dao.ChampionDao
import learn.programming.battleoftheimmortals.database.dao.InventoryItemDao
import learn.programming.battleoftheimmortals.database.model.account.Account
import learn.programming.battleoftheimmortals.database.model.actor.Champion
import learn.programming.battleoftheimmortals.database.model.actor.InventoryItem

@Database(entities = arrayOf(Account::class, Champion::class, InventoryItem::class), version = DBM.VERSION)
@TypeConverters(DBMTypeConverters::class)
abstract class DBM : RoomDatabase() {
    companion object {
        const val VERSION = 17
        private var sharedInstance: DBM? = null

        fun getSharedInstance() : DBM {
            val dbName = "BOTI$VERSION.db"
            if(sharedInstance == null)
                sharedInstance = Room.databaseBuilder(App.instance!!.applicationContext, DBM::class.java, dbName).allowMainThreadQueries().build()

            return sharedInstance!!
        }
    }

    abstract fun accountDao(): AccountDao
    abstract fun championDao(): ChampionDao
    abstract fun inventoryItemDao(): InventoryItemDao
}