package learn.programming.battleoftheimmortals.fragment.main.champion


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ScrollView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.fragment_floor.*
import kotlinx.android.synthetic.main.fragment_tower.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.adapter.TowerRecyclerViewAdapter
import learn.programming.battleoftheimmortals.utility.TowerObject.floors

/**
 * A simple [Fragment] subclass.
 */
class TowerFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_tower, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        towerRV.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = TowerRecyclerViewAdapter(this.context, floors.reversed())
        }

        //On fragment open,scroll down
        nsView.post {
            nsView.fullScroll(ScrollView.FOCUS_DOWN)
        }
    }
}

