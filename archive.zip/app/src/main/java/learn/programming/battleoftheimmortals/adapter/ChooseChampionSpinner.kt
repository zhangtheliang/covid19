package learn.programming.battleoftheimmortals.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.spinner_item.view.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.database.model.actor.Champion

class ChooseChampionSpinner(context: Context, items: List<Any>) : ArrayAdapter<Any>(context, R.layout.spinner_item,R.id.spinnerItemTV, items) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view = convertView
        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.spinner_item, null, false)
        }

        val currentItem = getItem(position)

        view?.spinnerItemTV?.text = (currentItem as Champion).name
        view?.spinnerItemRaceIV?.setImageResource((currentItem).race.icon)
        view?.spinnerItemProfessionIV?.setImageResource((currentItem).profession.icon)
        return view!!
    }

    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
        return getView(position, convertView, parent)
    }
}