package learn.programming.battleoftheimmortals.utility

import learn.programming.battleoftheimmortals.R.drawable
import learn.programming.battleoftheimmortals.database.model.account.Stat
import learn.programming.battleoftheimmortals.database.model.account.Stat.StatType.*
import learn.programming.battleoftheimmortals.database.model.actor.InventoryItem
import learn.programming.battleoftheimmortals.database.model.item.Item
import learn.programming.battleoftheimmortals.database.model.item.ItemEffect
//Item Data storage object
object ItemObject {

    fun getItemById(itemId: String) : Item? {
        return rings.find { it.id == itemId } ?:
        belts.find { it.id == itemId } ?:
        earrings.find { it.id == itemId } ?:
        necklaces.find { it.id == itemId } ?:
        helmets.find { it.id == itemId } ?:
        gloves.find { it.id == itemId } ?:
        boots.find { it.id == itemId } ?:
        chest.find { it.id == itemId } ?:
        weapon.find { it.id == itemId }
    }

    fun getItemByDbItem(item: InventoryItem) : Item? {
        val id = item.itemID
        val _item = rings.find { it.id == id } ?:
        belts.find { it.id == id } ?:
        earrings.find { it.id == id } ?:
        necklaces.find { it.id == id } ?:
        helmets.find { it.id == id } ?:
        gloves.find { it.id == id } ?:
        boots.find { it.id == id } ?:
        chest.find { it.id == id } ?:
        weapon.find { it.id == id }
        _item?.dbID = item.id
        return _item
    }

    var rings: MutableList<Item> = mutableListOf(
        Item(
            "Empty",
            "${Item.Type.RING}0",
            Item.Type.RING,
            10,
            Item.Tier.BASIC,
            drawable.empty_ring,
            mutableListOf(
                Stat(DAMAGE, 1)
            )
        ),
        Item(
            "Earth ring",
            "${Item.Type.RING}1",
            Item.Type.RING,
            10,
            Item.Tier.BASIC,
            drawable.ico_emerald_gunshin_ring,
            mutableListOf(
                Stat(STRENGTH, 1)
            ),
            1
        ),
        Item(
            "Air ring",
            "${Item.Type.RING}2",
            Item.Type.RING,
            10,
            Item.Tier.BASIC,
            drawable.ico_air_water_ring,
            mutableListOf(
                Stat(WISDOM, 1)

            ),1
        ),
        Item(
            "Water ring",
            "${Item.Type.RING}3",
            Item.Type.RING,
            10,
            Item.Tier.BASIC,
            drawable.ico_air_water_ring,
            mutableListOf(
                Stat(INTELLECT, 1)
            ),1
        ),
        Item(
            "Stone ring",
            "${Item.Type.RING}4",
            Item.Type.RING,
            10,
            Item.Tier.BASIC,
            drawable.ico_redstone_ring,
            mutableListOf(
                Stat(ARMOR, 1)
            ),1
        ),
        Item(
            "Diamond ring",
            "${Item.Type.RING}5",
            Item.Type.RING,
            95,
            Item.Tier.RARE,
            drawable.ico_zhang_dia_ring,
            mutableListOf(
                Stat(INTELLECT, 3)
            ),1
        ),
        Item(
            "Ruby ring",
            "${Item.Type.RING}6",
            Item.Type.RING,
            105,
            Item.Tier.RARE,
            drawable.ico_ruby_ring,
            mutableListOf(
                Stat(STRENGTH, 3)
            ),1
        ),
        Item(
            "Saphire ring",
            "${Item.Type.RING}7",
            Item.Type.RING,
            90,
            Item.Tier.RARE,
            drawable.ico_taii_ring,
            mutableListOf(
                Stat(HEAL, 1)
            ),1
        ),
        Item(
            "Emerald ring",
            "${Item.Type.WEAPON}8",
            Item.Type.RING,
            90,
            Item.Tier.RARE,
            drawable.ico_emerald_gunshin_ring,
            mutableListOf(
                Stat(AGILITY, 3)
            ),1
        ),
        Item(
            "Redstone ring",
            "${Item.Type.RING}9",
            Item.Type.RING,
            55,
            Item.Tier.RARE,
            drawable.ico_redstone_ring,
            mutableListOf(
                Stat(HIT_POINTS, 8)
            ),1
        ),
        Item(
            "Gold ring",
            "${Item.Type.RING}10",
            Item.Type.RING,
            45,
            Item.Tier.RARE,
            drawable.ico_gold_king_ring,
            mutableListOf(
                Stat(WISDOM, 3)
            ),1
        ),
        Item(
            "Black Death ring",
            "${Item.Type.RING}11",
            Item.Type.RING,
            240,
            Item.Tier.EPIC,
            drawable.ico_black_death_ring,
            mutableListOf(
                Stat(STRENGTH, 5),
                Stat(AGILITY, 3)
            ),1
        ),
        Item(
            "Blood ring",
            "${Item.Type.RING}12",
            Item.Type.RING,
            215,
            Item.Tier.EPIC,
            drawable.ico_blood_ring,
            mutableListOf(
                Stat(AGILITY, 6)
            ),1
        ),
        Item(
            "Hit ring",
            "${Item.Type.RING}13",
            Item.Type.RING,
            190,
            Item.Tier.EPIC,
            drawable.ico_hit_ring,
            mutableListOf(
                Stat(DAMAGE, 5)
            ),1
        ),
        Item(
            "Mortal ring",
            "${Item.Type.RING}14",
            Item.Type.RING,
            210,
            Item.Tier.EPIC,
            drawable.ico_mortal_ring,
            mutableListOf(
                Stat(CRIT_RATE, 2),
                Stat(DAMAGE, 1)
            ),1
        ),
        Item(
            "Arena ring",
            "${Item.Type.RING}15",
            Item.Type.RING,
            230,
            Item.Tier.EPIC,
            drawable.ico_arena_ring,
            mutableListOf(
                Stat(ACCURACY, 3),
                Stat(INTELLECT, 3)
            ),1
        ),
        Item(
            "King's ring",
            "${Item.Type.RING}16",
            Item.Type.RING,
            105,
            Item.Tier.NOBLE,
            drawable.ico_gold_king_ring,
            mutableListOf(
                Stat(HIT_POINTS, 10),
                Stat(DAMAGE, 2)
            ),1
        ),
        Item(
            "Prince ring",
            "${Item.Type.RING}17",
            Item.Type.RING,
            90,
            Item.Tier.NOBLE,
            drawable.ico_gold_king_ring,
            mutableListOf(
                Stat(ARMOR, 12)
            ),1
        ),
        Item(
            "Priest's ring",
            "${Item.Type.RING}18",
            Item.Type.RING,
            100,
            Item.Tier.NOBLE,
            drawable.ico_priest_ring,
            mutableListOf(
                Stat(HEAL, 2)
            ),1
        ),
        Item(
            "Zeus's ring",
            "${Item.Type.RING}19",
            Item.Type.RING,
            500,
            Item.Tier.HEROIC,
            drawable.ico_priest_ring,
            mutableListOf(
                Stat(STRENGTH, 7),
                Stat(INTELLECT, 7)
            ),1
        ),
        Item(
            "ZhangLiang's ring",
            "${Item.Type.RING}20",
            Item.Type.RING,
            730,
            Item.Tier.HEROIC,
            drawable.ico_zhang_dia_ring,
            mutableListOf(
                Stat(STRENGTH, 10),
                Stat(ACCURACY, 3)
            ),1
        ),
        Item(
            "Gunshin's ring",
            "${Item.Type.RING}21",
            Item.Type.RING,
            800,
            Item.Tier.HEROIC,
            drawable.ico_emerald_gunshin_ring,
            mutableListOf(
                Stat(INTELLECT, 9)
            ),1
        ),
        Item(
            "Taii's ring",
            "${Item.Type.RING}22",
            Item.Type.RING,
            750,
            Item.Tier.HEROIC,
            drawable.ico_taii_ring,
            mutableListOf(
                Stat(CRIT_RATE, 5)
            ),1
        ),
        Item(
            "Ring of Destruction",
            "${Item.Type.RING}23",
            Item.Type.RING,
            1200,
            Item.Tier.LEGENDARY,
            drawable.ico_brod_ring,
            mutableListOf(
                Stat(INTELLECT, 8),
                Stat(ACCURACY, 5)
            ),1
        ),
        Item(
            "Ring of chaos",
            "${Item.Type.RING}24",
            Item.Type.RING,
            1300,
            Item.Tier.LEGENDARY,
            drawable.ico_chaos_ring,
            mutableListOf(
                Stat(STRENGTH, 8),
                Stat(AGILITY, 8),
                Stat(CRIT_RATE, 4)
            ),1
        ),
        Item(
            "Dark Brotherhood ring",
            "${Item.Type.RING}25",
            Item.Type.RING,
            1900,
            Item.Tier.LEGENDARY,
            drawable.ico_darkb_ring,
            mutableListOf(
                Stat(AGILITY, 10),
                Stat(ACCURACY, 5)
            ),1
        ),
        Item(
            "Elder Ring",
            "${Item.Type.RING}26",
            Item.Type.RING,
            2000,
            Item.Tier.LEGENDARY,
            drawable.ico_elder_ring,
            mutableListOf(
                Stat(HEAL, 1),
                Stat(WISDOM, 10),
                Stat(HIT_POINTS, 20)
            ),1
        )
    )
    var belts: MutableList<Item> = mutableListOf(
        Item(
            "Empty",
            "${Item.Type.BELT}0",
            Item.Type.BELT,
            10,
            Item.Tier.BASIC,
            drawable.empty_belt,
            mutableListOf(
            )
        ),
        Item(
            "Earth belt",
            "${Item.Type.BELT}1",
            Item.Type.BELT,
            10,
            Item.Tier.BASIC,
            drawable.earth_gold_belt,
            mutableListOf(
                Stat(STRENGTH, 1)
            ),1
        ),
        Item(
            "Water belt",
            "${Item.Type.BELT}2",
            Item.Type.BELT,
            10,
            Item.Tier.BASIC,
            drawable.water_air_belt,
            mutableListOf(
                Stat(AGILITY, 3)
            ),1
        ),
        Item(
            "Air belt",
            "${Item.Type.BELT}3",
            Item.Type.BELT,
            10,
            Item.Tier.BASIC,
            drawable.water_air_belt,
            mutableListOf(
                Stat(WISDOM, 1)
            ),1
        ),
        Item(
            "Diamond belt",
            "${Item.Type.BELT}4",
            Item.Type.BELT,
            120,
            Item.Tier.RARE,
            drawable.diamond_belt,
            mutableListOf(
                Stat(INTELLECT, 2)
            ),1
        ),
        Item(
            "Saphire belt",
            "${Item.Type.BELT}5",
            Item.Type.BELT,
            95,
            Item.Tier.RARE,
            drawable.eme_ruby_saph_belt,
            mutableListOf(
                Stat(AGILITY, 2)
            ),1
        ),
        Item(
            "Emerald belt",
            "${Item.Type.BELT}6",
            Item.Type.BELT,
            80,
            Item.Tier.RARE,
            drawable.eme_ruby_saph_belt,
            mutableListOf(
                Stat(ARMOR, 1)
            ),1
        ),
        Item(
            "Ruby belt",
            "${Item.Type.BELT}7",
            Item.Type.BELT,
            85,
            Item.Tier.RARE,
            drawable.eme_ruby_saph_belt,
            mutableListOf(
                Stat(DAMAGE, 1)
            ),1
        ),
        Item(
            "Black Death belt",
            "${Item.Type.BELT}8",
            Item.Type.BELT,
            220,
            Item.Tier.EPIC,
            drawable.blood_belt,
            mutableListOf(
                Stat(DAMAGE, 3)
            ),1
        ),
        Item(
            "Blood belt",
            "${Item.Type.BELT}9",
            Item.Type.BELT,
            230,
            Item.Tier.EPIC,
            drawable.blood_belt,
            mutableListOf(
                Stat(STRENGTH, 3)
            ),1
        ),
        Item(
            "Mortal belt",
            "${Item.Type.BELT}10",
            Item.Type.BELT,
            200,
            Item.Tier.EPIC,
            drawable.taii_mortal_belt,
            mutableListOf(
                Stat(CRIT_RATE, 2)
            ),1
        ),
        Item(
            "Arena belt",
            "${Item.Type.BELT}11",
            Item.Type.BELT,
            215,
            Item.Tier.EPIC,
            drawable.zhang_arena_belt,
            mutableListOf(
                Stat(HIT_POINTS, 18),
                Stat(DAMAGE, 1)
            ),1
        ),
        Item(
            "King's BELT",
            "${Item.Type.BELT}12",
            Item.Type.BELT,
            115,
            Item.Tier.NOBLE,
            drawable.king_belt,
            mutableListOf(
                Stat(STRENGTH, 4)
            ),1
        ),
        Item(
            "Prince belt",
            "${Item.Type.BELT}13",
            Item.Type.BELT,
            110,
            Item.Tier.NOBLE,
            drawable.prince_belt,
            mutableListOf(
                Stat(AGILITY, 4)
            ),1
        ),
        Item(
            "Priest's belt",
            "${Item.Type.BELT}14",
            Item.Type.BELT,
            150,
            Item.Tier.NOBLE,
            drawable.priest_belt,
            mutableListOf(
                Stat(WISDOM, 4)
            ),1
        ),
        Item(
            "Zeus's belt",
            "${Item.Type.BELT}15",
            Item.Type.BELT,
            450,
            Item.Tier.HEROIC,
            drawable.zeus_belt,
            mutableListOf(
                Stat(STRENGTH, 4),
                Stat(INTELLECT, 4)
            ),1
        ),
        Item(
            "Gunshin's belt",
            "${Item.Type.BELT}16",
            Item.Type.BELT,
            1200,
            Item.Tier.HEROIC,
            drawable.gunshin_belt,
            mutableListOf(
                Stat(INTELLECT, 7)
            ),1
        ),
        Item(
            "Zhangliang's belt",
            "${Item.Type.BELT}17",
            Item.Type.BELT,
            800,
            Item.Tier.HEROIC,
            drawable.zhang_arena_belt,
            mutableListOf(
                Stat(STRENGTH, 4),
                Stat(ACCURACY, 4)
            ),1
        ),
        Item(
            "Taii's belt",
            "${Item.Type.BELT}18",
            Item.Type.BELT,
            400,
            Item.Tier.HEROIC,
            drawable.taii_mortal_belt,
            mutableListOf(
                Stat(CRIT_RATE, 2),
                Stat(AGILITY, 4)
            ),1
        ),
        Item(
            "Destruction Belt",
            "${Item.Type.BELT}19",
            Item.Type.BELT,
            1500,
            Item.Tier.LEGENDARY,
            drawable.exlposion_belt,
            mutableListOf(
                Stat(INTELLECT, 8),
                Stat(CRIT_RATE, 3)
            ),1
        ),
        Item(
            "War belt",
            "${Item.Type.BELT}20",
            Item.Type.BELT,
            2050,
            Item.Tier.LEGENDARY,
            drawable.war_wind_belt,
            mutableListOf(
                Stat(STRENGTH, 5),
                Stat(ARMOR, 5)
            ),1
        ),
        Item(
            "Old god's belt",
            "${Item.Type.BELT}21",
            Item.Type.BELT,
            2200,
            Item.Tier.LEGENDARY,
            drawable.oldgod_belt,
            mutableListOf(
                Stat(WISDOM, 10)
            ),1
        ),
        Item(
            "Explosion belt",
            "${Item.Type.BELT}22",
            Item.Type.BELT,
            2000,
            Item.Tier.LEGENDARY,
            drawable.exlposion_belt,
            mutableListOf(
                Stat(AGILITY, 9),
                Stat(INTELLECT, 6)

            ),1
        )
    )
    var earrings: MutableList<Item> = mutableListOf(
        Item(
            "Empty",
            "${Item.Type.EARRING}0",
            Item.Type.EARRING,
            10,
            Item.Tier.BASIC,
            drawable.empty_earing,
            mutableListOf(
                Stat(DAMAGE, 1)
            )
        ),
        Item(
            "Earth earring",
            "${Item.Type.EARRING}1",
            Item.Type.EARRING,
            10,
            Item.Tier.BASIC,
            drawable.earth_basic_earing,
            mutableListOf(
                Stat(STRENGTH, 1)
            ),1
        ),
        Item(
            "Air earing",
            "${Item.Type.EARRING}2",
            Item.Type.EARRING,
            10,
            Item.Tier.BASIC,
            drawable.all_diamond_earing,
            mutableListOf(
                Stat(WISDOM, 1)

            ),1
        ),
        Item(
            "Water earing",
            "${Item.Type.EARRING}3",
            Item.Type.EARRING,
            10,
            Item.Tier.BASIC,
            drawable.all_diamond_earing,
            mutableListOf(
                Stat(INTELLECT, 1)
            ),1
        ),
        Item(
            "Stone earing",
            "${Item.Type.EARRING}4",
            Item.Type.EARRING,
            10,
            Item.Tier.BASIC,
            drawable.all_diamond_earing,
            mutableListOf(
                Stat(ARMOR, 1)
            ),1
        ),
        Item(
            "Diamond earing",
            "${Item.Type.EARRING}5",
            Item.Type.EARRING,
            95,
            Item.Tier.RARE,
            drawable.all_diamond_earing,
            mutableListOf(
                Stat(INTELLECT, 3)
            ),1
        ),
        Item(
            "Ruby earing",
            "${Item.Type.EARRING}6",
            Item.Type.EARRING,
            105,
            Item.Tier.RARE,
            drawable.ruby_redstone_earing,
            mutableListOf(
                Stat(STRENGTH, 3)
            ),1
        ),
        Item(
            "Redstone earing",
            "${Item.Type.EARRING}7",
            Item.Type.EARRING,
            55,
            Item.Tier.RARE,
            drawable.ruby_redstone_earing,
            mutableListOf(
                Stat(HIT_POINTS, 25)
            ),1
        ),
        Item(
            "Gold earing",
            "${Item.Type.EARRING}8",
            Item.Type.EARRING,
            45,
            Item.Tier.RARE,
            drawable.taii_prince_gold_earing,
            mutableListOf(
                Stat(WISDOM, 3)
            ),1
        ),
        Item(
            "Black Death earing",
            "${Item.Type.EARRING}9",
            Item.Type.EARRING,
            260,
            Item.Tier.EPIC,
            drawable.arena_hit_black_earing,
            mutableListOf(
                Stat(STRENGTH, 6),
                Stat(AGILITY, 3)
            ),1
        ),
        Item(
            "Blood earing",
            "${Item.Type.EARRING}10",
            Item.Type.EARRING,
            245,
            Item.Tier.EPIC,
            drawable.ruby_redstone_earing,
            mutableListOf(
                Stat(AGILITY, 4)
            ),1
        ),
        Item(
            "Hit earing",
            "${Item.Type.EARRING}11",
            Item.Type.EARRING,
            220,
            Item.Tier.EPIC,
            drawable.arena_hit_black_earing,
            mutableListOf(
                Stat(DAMAGE, 3)
            ),1
        ),
        Item(
            "Mortal earing",
            "${Item.Type.EARRING}12",
            Item.Type.EARRING,
            250,
            Item.Tier.EPIC,
            drawable.mortal_gunshin_earing,
            mutableListOf(
                Stat(CRIT_RATE, 1),
                Stat(DAMAGE, 2)
            ),1
        ),
        Item(
            "Arena earing",
            "${Item.Type.EARRING}13",
            Item.Type.EARRING,
            250,
            Item.Tier.EPIC,
            drawable.arena_hit_black_earing,
            mutableListOf(
                Stat(ACCURACY, 2),
                Stat(INTELLECT, 4)
            ),1
        ),
        Item(
            "King's earing",
            "${Item.Type.EARRING}14",
            Item.Type.EARRING,
            120,
            Item.Tier.NOBLE,
            drawable.zhang_king_earing,
            mutableListOf(
                Stat(HIT_POINTS, 40),
                Stat(DAMAGE, 4)
            ),1
        ),
        Item(
            "Prince earing",
            "${Item.Type.EARRING}15",
            Item.Type.EARRING,
            100,
            Item.Tier.NOBLE,
            drawable.taii_prince_gold_earing,
            mutableListOf(
                Stat(ARMOR, 5)
            ),1
        ),
        Item(
            "Priest's earing",
            "${Item.Type.EARRING}16",
            Item.Type.EARRING,
            120,
            Item.Tier.NOBLE,
            drawable.elder_priest_earing,
            mutableListOf(
                Stat(HEAL, 1),
                Stat(WISDOM, 4)
            ),1
        ),
        Item(
            "Zeus's earing",
            "${Item.Type.EARRING}17",
            Item.Type.EARRING,
            550,
            Item.Tier.HEROIC,
            drawable.earth_basic_earing,
            mutableListOf(
                Stat(STRENGTH, 9),
                Stat(INTELLECT, 7)
            ),1
        ),
        Item(
            "ZhangLiang's earing",
            "${Item.Type.EARRING}18",
            Item.Type.EARRING,
            780,
            Item.Tier.HEROIC,
            drawable.all_diamond_earing,
            mutableListOf(
                Stat(STRENGTH, 12),
                Stat(ACCURACY, 3)
            ),1
        ),
        Item(
            "Gunshin's earing",
            "${Item.Type.EARRING}19",
            Item.Type.EARRING,
            850,
            Item.Tier.HEROIC,
            drawable.mortal_gunshin_earing,
            mutableListOf(
                Stat(INTELLECT, 10)
            ),1
        ),
        Item(
            "Taii's earing",
            "${Item.Type.EARRING}20",
            Item.Type.EARRING,
            850,
            Item.Tier.HEROIC,
            drawable.taii_prince_gold_earing,
            mutableListOf(
                Stat(CRIT_RATE, 5)
            ),1
        ),
        Item(
            "Earing of Destruction",
            "${Item.Type.EARRING}21",
            Item.Type.EARRING,
            1300,
            Item.Tier.LEGENDARY,
            drawable.arena_hit_black_earing,
            mutableListOf(
                Stat(INTELLECT, 10),
                Stat(ACCURACY, 3)
            ),1
        ),
        Item(
            "Earing of chaos",
            "${Item.Type.EARRING}22",
            Item.Type.EARRING,
            1400,
            Item.Tier.LEGENDARY,
            drawable.chaos_earing,
            mutableListOf(
                Stat(STRENGTH, 12),
                Stat(AGILITY, 6),
                Stat(CRIT_RATE, 2)
            ),1
        ),
        Item(
            "Dark Brotherhood earing",
            "${Item.Type.EARRING}23",
            Item.Type.EARRING,
            2100,
            Item.Tier.LEGENDARY,
            drawable.darkb_earing,
            mutableListOf(
                Stat(AGILITY, 12),
                Stat(ACCURACY, 8)
            ),1
        ),
        Item(
            "Elder earing",
            "${Item.Type.EARRING}24",
            Item.Type.EARRING,
            2300,
            Item.Tier.LEGENDARY,
            drawable.elder_priest_earing,
            mutableListOf(
                Stat(HEAL, 2),
                Stat(WISDOM, 10),
                Stat(HIT_POINTS, 50)
            ),1
        )
    )
    var necklaces: MutableList<Item> = mutableListOf(
        Item(
            "Empty",
            "${Item.Type.NECKLACE}0",
            Item.Type.NECKLACE,
            10,
            Item.Tier.BASIC,
            drawable.empty_neck,
            mutableListOf(
                Stat(DAMAGE, 1)
            )
        ),
        Item(
            "Air necklace",
            "${Item.Type.NECKLACE}1",
            Item.Type.NECKLACE,
            10,
            Item.Tier.BASIC,
            drawable.zeus_diamond_air_neck,
            mutableListOf(
                Stat(WISDOM, 1)

            ),1
        ),
        Item(
            "Water necklace",
            "${Item.Type.NECKLACE}2",
            Item.Type.NECKLACE,
            10,
            Item.Tier.BASIC,
            drawable.water_stone_neck,
            mutableListOf(
                Stat(INTELLECT, 1)
            ),1
        ),
        Item(
            "Stone necklace",
            "${Item.Type.NECKLACE}3",
            Item.Type.NECKLACE,
            10,
            Item.Tier.BASIC,
            drawable.water_stone_neck,
            mutableListOf(
                Stat(ARMOR, 1)
            ),1
        ),
        Item(
            "Diamond necklace",
            "${Item.Type.NECKLACE}4",
            Item.Type.NECKLACE,
            95,
            Item.Tier.RARE,
            drawable.zeus_diamond_air_neck,
            mutableListOf(
                Stat(INTELLECT, 3)
            ),1
        ),
        Item(
            "Ruby necklace",
            "${Item.Type.NECKLACE}5",
            Item.Type.NECKLACE,
            105,
            Item.Tier.RARE,
            drawable.gold_redstone_prince_king_neck,
            mutableListOf(
                Stat(STRENGTH, 3)
            ),1
        ),
        Item(
            "Redstone necklace",
            "${Item.Type.NECKLACE}6",
            Item.Type.NECKLACE,
            55,
            Item.Tier.RARE,
            drawable.gold_redstone_prince_king_neck,
            mutableListOf(
                Stat(HIT_POINTS, 30)
            ),1
        ),
        Item(
            "Gold necklace",
            "${Item.Type.NECKLACE}7",
            Item.Type.NECKLACE,
            45,
            Item.Tier.RARE,
            drawable.gold_redstone_prince_king_neck,
            mutableListOf(
                Stat(WISDOM, 3)
            ),1
        ),
        Item(
            "Black Death necklace",
            "${Item.Type.NECKLACE}8",
            Item.Type.NECKLACE,
            290,
            Item.Tier.EPIC,
            drawable.bnod_gunshin_neck,
            mutableListOf(
                Stat(STRENGTH, 5),
                Stat(AGILITY, 3)
            ),1
        ),
        Item(
            "Blood necklace",
            "${Item.Type.NECKLACE}9",
            Item.Type.NECKLACE,
            345,
            Item.Tier.EPIC,
            drawable.gold_redstone_prince_king_neck,
            mutableListOf(
                Stat(AGILITY, 5)
            ),1
        ),
        Item(
            "Hit necklace",
            "${Item.Type.NECKLACE}10",
            Item.Type.NECKLACE,
            280,
            Item.Tier.EPIC,
            drawable.taii_hit_neck,
            mutableListOf(
                Stat(DAMAGE, 5)
            ),1
        ),
        Item(
            "Mortal necklace",
            "${Item.Type.NECKLACE}11",
            Item.Type.NECKLACE,
            280,
            Item.Tier.EPIC,
            drawable.arena_mortal_neck,
            mutableListOf(
                Stat(CRIT_RATE, 2),
                Stat(DAMAGE, 3)
            ),1
        ),
        Item(
            "Arena necklace",
            "${Item.Type.NECKLACE}12",
            Item.Type.NECKLACE,
            290,
            Item.Tier.EPIC,
            drawable.arena_mortal_neck,
            mutableListOf(
                Stat(ACCURACY, 3),
                Stat(INTELLECT, 4)
            ),1
        ),
        Item(
            "King's necklace",
            "${Item.Type.NECKLACE}13",
            Item.Type.NECKLACE,
            150,
            Item.Tier.NOBLE,
            drawable.gold_redstone_prince_king_neck,
            mutableListOf(
                Stat(HIT_POINTS, 50),
                Stat(DAMAGE, 2)
            ),1
        ),
        Item(
            "Prince necklace",
            "${Item.Type.NECKLACE}14",
            Item.Type.NECKLACE,
            140,
            Item.Tier.NOBLE,
            drawable.gold_redstone_prince_king_neck,
            mutableListOf(
                Stat(ARMOR, 5),
                Stat(AGILITY, 3)
            ),1
        ),
        Item(
            "Priest's necklace",
            "${Item.Type.NECKLACE}15",
            Item.Type.NECKLACE,
            150,
            Item.Tier.NOBLE,
            drawable.priest_neck,
            mutableListOf(
                Stat(HEAL, 1),
                Stat(WISDOM,2)
            ),1
        ),
        Item(
            "Zeus's necklace",
            "${Item.Type.NECKLACE}16",
            Item.Type.NECKLACE,
            750,
            Item.Tier.HEROIC,
            drawable.zeus_diamond_air_neck,
            mutableListOf(
                Stat(STRENGTH, 10),
                Stat(INTELLECT, 8)
            ),1
        ),
        Item(
            "ZhangLiang's necklace",
            "${Item.Type.NECKLACE}17",
            Item.Type.NECKLACE,
            1080,
            Item.Tier.HEROIC,
            drawable.chaos_zang_neck,
            mutableListOf(
                Stat(STRENGTH, 13),
                Stat(ACCURACY, 4)
            ),1
        ),
        Item(
            "Gunshin's necklace",
            "${Item.Type.NECKLACE}18",
            Item.Type.NECKLACE,
            950,
            Item.Tier.HEROIC,
            drawable.bnod_gunshin_neck,
            mutableListOf(
                Stat(INTELLECT, 13)
            ),1
        ),
        Item(
            "Taii's necklace",
            "${Item.Type.NECKLACE}19",
            Item.Type.NECKLACE,
            950,
            Item.Tier.HEROIC,
            drawable.taii_hit_neck,
            mutableListOf(
                Stat(CRIT_RATE, 4)
            ),1
        ),
        Item(
            "Necklace of Destruction",
            "${Item.Type.NECKLACE}20",
            Item.Type.NECKLACE,
            1400,
            Item.Tier.LEGENDARY,
            drawable.bnod_gunshin_neck,
            mutableListOf(
                Stat(INTELLECT, 14),
                Stat(ACCURACY, 3)
            ),1
        ),
        Item(
            "Necklace of chaos",
            "${Item.Type.NECKLACE}21",
            Item.Type.NECKLACE,
            1500,
            Item.Tier.LEGENDARY,
            drawable.chaos_zang_neck,
            mutableListOf(
                Stat(STRENGTH, 12),
                Stat(AGILITY, 8),
                Stat(CRIT_RATE, 2)
            ),1
        ),
        Item(
            "Dark Brotherhood necklace",
            "${Item.Type.NECKLACE}22",
            Item.Type.NECKLACE,
            2300,
            Item.Tier.LEGENDARY,
            drawable.darb_bd_neck,
            mutableListOf(
                Stat(AGILITY, 8),
                Stat(ACCURACY, 5)
            ),1
        ),
        Item(
            "Elder necklace",
            "${Item.Type.NECKLACE}23",
            Item.Type.NECKLACE,
            2600,
            Item.Tier.LEGENDARY,
            drawable.priest_neck,
            mutableListOf(
                Stat(HEAL, 2),
                Stat(WISDOM, 12),
                Stat(HIT_POINTS, 50)
            ),1
        )
    )
    var helmets: MutableList<Item> = mutableListOf(
        Item(
            "Empty",
            "${Item.Type.HELMET}0",
            Item.Type.HELMET,
            10,
            Item.Tier.BASIC,
            drawable.empty_helmet,
            mutableListOf(
                Stat(ARMOR, 1)
            )
        ),
        Item(
            "Basic hat",
            "${Item.Type.HELMET}1",
            Item.Type.HELMET,
            10,
            Item.Tier.BASIC,
            drawable.hat_helmet,
            mutableListOf(
                Stat(AGILITY, 1)

            ),1
        ),
        Item(
            "Iron helmet",
            "${Item.Type.HELMET}2",
            Item.Type.HELMET,
            115,
            Item.Tier.RARE,
            drawable.king_iron_basic_helmet,
            mutableListOf(
                Stat(ARMOR, 2)
            ),1
        ),
        Item(
            "Platinum helmet",
            "${Item.Type.HELMET}3",
            Item.Type.HELMET,
            135,
            Item.Tier.RARE,
            drawable.plat_silver_helmet,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(STRENGTH, 2)
            ),1
        ),
        Item(
            "Silver helmet",
            "${Item.Type.HELMET}4",
            Item.Type.HELMET,
            100,
            Item.Tier.RARE,
            drawable.plat_silver_helmet,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(WISDOM, 3)
            ),1
        ),
        Item(
            "Gold helmet",
            "${Item.Type.HELMET}5",
            Item.Type.HELMET,
            110,
            Item.Tier.RARE,
            drawable.prince_gold_helmet,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(WISDOM, 3)
            ),1
        ),
        Item(
            "Black Death helmet",
            "${Item.Type.HELMET}6",
            Item.Type.HELMET,
            330,
            Item.Tier.EPIC,
            drawable.bhod_helmet,
            mutableListOf(
                Stat(ARMOR, 3),
                Stat(AGILITY, 2)
            ),1
        ),
        Item(
            "Bloodmark helmet",
            "${Item.Type.HELMET}7",
            Item.Type.HELMET,
            335,
            Item.Tier.EPIC,
            drawable.gunshin_redstone_blood_helmet,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(HIT_POINTS, 30)
            ),1
        ),
        Item(
            "Charge helmet",
            "${Item.Type.HELMET}8",
            Item.Type.HELMET,
            360,
            Item.Tier.EPIC,
            drawable.charge_mortal_arena_helmet,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(DAMAGE, 4)
            ),1
        ),
        Item(
            "Mortal helmet",
            "${Item.Type.HELMET}9",
            Item.Type.HELMET,
            380,
            Item.Tier.EPIC,
            drawable.mortal_helmet,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(CRIT_RATE, 1),
                Stat(DAMAGE, 2)
            ),1
        ),
        Item(
            "Arena helmet",
            "${Item.Type.HELMET}10",
            Item.Type.HELMET,
            350,
            Item.Tier.EPIC,
            drawable.charge_mortal_arena_helmet,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(ACCURACY, 2),
                Stat(EVASION, 1)
            ),1
        ),
        Item(
            "King's helmet",
            "${Item.Type.HELMET}11",
            Item.Type.HELMET,
            250,
            Item.Tier.NOBLE,
            drawable.king_iron_basic_helmet,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(HIT_POINTS, 30),
                Stat(DAMAGE, 2),
                Stat(EVASION, 1)
            ),1
        ),
        Item(
            "Prince helmet",
            "${Item.Type.HELMET}12",
            Item.Type.HELMET,
            140,
            Item.Tier.NOBLE,
            drawable.prince_gold_helmet,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(HIT_POINTS, 40)
            ),1
        ),
        Item(
            "Priest's helmet",
            "${Item.Type.HELMET}13",
            Item.Type.HELMET,
            150,
            Item.Tier.NOBLE,
            drawable.priest_elder_helmet,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(WISDOM, 6),
                Stat(EVASION, 1)
            ),1
        ),
        Item(
            "Zeus's helmet",
            "${Item.Type.HELMET}14",
            Item.Type.HELMET,
            950,
            Item.Tier.HEROIC,
            drawable.zeus_diamond_helmet,
            mutableListOf(
                Stat(ARMOR, 3),
                Stat(STRENGTH, 3),
                Stat(INTELLECT, 6),
                Stat(HIT_POINTS, 40),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "ZhangLiang's helmet",
            "${Item.Type.HELMET}15",
            Item.Type.HELMET,
            1480,
            Item.Tier.HEROIC,
            drawable.chaos_zhangg_helmet,
            mutableListOf(
                Stat(ARMOR, 4),
                Stat(STRENGTH, 5),
                Stat(ACCURACY, 3),
                Stat(HIT_POINTS, 50),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Gunshin's helmet",
            "${Item.Type.HELMET}16",
            Item.Type.HELMET,
            1450,
            Item.Tier.HEROIC,
            drawable.gunshin_redstone_blood_helmet,
            mutableListOf(
                Stat(ARMOR, 3),
                Stat(INTELLECT, 10),
                Stat(HIT_POINTS, 25),
                Stat(EVASION, 4)
            ),1
        ),
        Item(
            "Taii's helmet",
            "${Item.Type.HELMET}17",
            Item.Type.HELMET,
            1350,
            Item.Tier.HEROIC,
            drawable.darb_taii_helmet,
            mutableListOf(
                Stat(ARMOR, 3),
                Stat(CRIT_RATE, 2),
                Stat(HIT_POINTS, 30),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Helmet of Destruction",
            "${Item.Type.HELMET}18",
            Item.Type.HELMET,
            2200,
            Item.Tier.LEGENDARY,
            drawable.bhod_helmet,
            mutableListOf(
                Stat(ARMOR, 3),
                Stat(INTELLECT, 10),
                Stat(ACCURACY, 5),
                Stat(HIT_POINTS, 30),
                Stat(EVASION, 6)
            ),1
        ),
        Item(
            "Helmet of chaos",
            "${Item.Type.HELMET}19",
            Item.Type.HELMET,
            2500,
            Item.Tier.LEGENDARY,
            drawable.chaos_zhangg_helmet,
            mutableListOf(
                Stat(ARMOR, 6),
                Stat(STRENGTH, 7),
                Stat(AGILITY, 7),
                Stat(HIT_POINTS, 80),
                Stat(EVASION, 3)
            ),1
        ),
        Item(
            "Dark Brotherhood helmet",
            "${Item.Type.HELMET}20",
            Item.Type.HELMET,
            3300,
            Item.Tier.LEGENDARY,
            drawable.darb_taii_helmet,
            mutableListOf(
                Stat(ARMOR, 4),
                Stat(AGILITY, 12),
                Stat(ACCURACY, 5),
                Stat(HIT_POINTS, 50),
                Stat(EVASION, 3)
            ),1
        ),
        Item(
            "Elder helmet",
            "${Item.Type.HELMET}21",
            Item.Type.HELMET,
            3600,
            Item.Tier.LEGENDARY,
            drawable.priest_elder_helmet,
            mutableListOf(
                Stat(ARMOR, 7),
                Stat(HEAL, 1),
                Stat(WISDOM, 12),
                Stat(HIT_POINTS, 100),
                Stat(EVASION, 3)
            ),1
        )
    )
    var gloves: MutableList<Item> = mutableListOf(
        Item(
            "Empty",
            "${Item.Type.GLOVES}0",
            Item.Type.GLOVES,
            10,
            Item.Tier.BASIC,
            drawable.empty_gloves,
            mutableListOf(
                Stat(ARMOR, 1)
            )
        ),
        Item(
            "Basic handguards",
            "${Item.Type.GLOVES}1",
            Item.Type.GLOVES,
            10,
            Item.Tier.BASIC,
            drawable.hand_gloves,
            mutableListOf(
                Stat(WISDOM, 1)
            ),1
        ),
        Item(
            "Basic vambraces",
            "${Item.Type.GLOVES}2",
            Item.Type.GLOVES,
            10,
            Item.Tier.BASIC,
            drawable.vamb_gloves,
            mutableListOf(
                Stat(AGILITY, 1)

            ),1
        ),
        Item(
            "Iron gloves",
            "${Item.Type.GLOVES}3",
            Item.Type.GLOVES,
            115,
            Item.Tier.RARE,
            drawable.zeus_iron_plat_gloves,
            mutableListOf(
                Stat(ARMOR, 2)
            ),1
        ),
        Item(
            "Platinum gloves",
            "${Item.Type.GLOVES}4",
            Item.Type.GLOVES,
            135,
            Item.Tier.RARE,
            drawable.zeus_iron_plat_gloves,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(STRENGTH, 2)
            ),1
        ),
        Item(
            "Silver gloves",
            "${Item.Type.GLOVES}5",
            Item.Type.GLOVES,
            100,
            Item.Tier.RARE,
            drawable.elder_silver_priest_gloves,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(WISDOM, 3)
            ),1
        ),
        Item(
            "Gold gloves",
            "${Item.Type.GLOVES}6",
            Item.Type.GLOVES,
            110,
            Item.Tier.RARE,
            drawable.prince_gold_gloves,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(WISDOM, 3)
            ),1
        ),
        Item(
            "Black Death gloves",
            "${Item.Type.GLOVES}7",
            Item.Type.GLOVES,
            330,
            Item.Tier.EPIC,
            drawable.bgod_gunshin_gloves,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(AGILITY, 2)
            ),1
        ),
        Item(
            "Bloodmark gloves",
            "${Item.Type.GLOVES}8",
            Item.Type.GLOVES,
            335,
            Item.Tier.EPIC,
            drawable.blood_taii_gloves,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(HIT_POINTS, 33)
            ),1
        ),
        Item(
            "Charge gloves",
            "${Item.Type.GLOVES}9",
            Item.Type.GLOVES,
            360,
            Item.Tier.EPIC,
            drawable.charge_gloves,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(DAMAGE, 4)
            ),1
        ),
        Item(
            "Mortal gloves",
            "${Item.Type.GLOVES}10",
            Item.Type.GLOVES,
            380,
            Item.Tier.EPIC,
            drawable.mortal_gloves,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(CRIT_RATE, 1),
                Stat(DAMAGE, 2)
            ),1
        ),
        Item(
            "Arena gloves",
            "${Item.Type.GLOVES}11",
            Item.Type.GLOVES,
            350,
            Item.Tier.EPIC,
            drawable.arena_gloves,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(ACCURACY, 2)
            ),1
        ),
        Item(
            "King's gloves",
            "${Item.Type.GLOVES}12",
            Item.Type.GLOVES,
            250,
            Item.Tier.NOBLE,
            drawable.king_gloves,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(HIT_POINTS, 55),
                Stat(DAMAGE, 2),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Prince gloves",
            "${Item.Type.GLOVES}13",
            Item.Type.GLOVES,
            140,
            Item.Tier.NOBLE,
            drawable.prince_gold_gloves,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(HIT_POINTS, 45),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Priest's gloves",
            "${Item.Type.GLOVES}14",
            Item.Type.GLOVES,
            150,
            Item.Tier.NOBLE,
            drawable.elder_silver_priest_gloves,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(WISDOM, 2),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Zeus's gloves",
            "${Item.Type.GLOVES}15",
            Item.Type.GLOVES,
            850,
            Item.Tier.HEROIC,
            drawable.zeus_iron_plat_gloves,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(STRENGTH, 5),
                Stat(INTELLECT, 5),
                Stat(HIT_POINTS, 40),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "ZhangLiang's gloves",
            "${Item.Type.GLOVES}16",
            Item.Type.GLOVES,
            1380,
            Item.Tier.HEROIC,
            drawable.chaos_gloves,
            mutableListOf(
                Stat(ARMOR, 3),
                Stat(STRENGTH, 5),
                Stat(ACCURACY, 4),
                Stat(HIT_POINTS, 40),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Gunshin's gloves",
            "${Item.Type.GLOVES}17",
            Item.Type.GLOVES,
            1350,
            Item.Tier.HEROIC,
            drawable.bgod_gunshin_gloves,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(INTELLECT, 8),
                Stat(HIT_POINTS, 20),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Taii's gloves",
            "${Item.Type.GLOVES}18",
            Item.Type.GLOVES,
            1250,
            Item.Tier.HEROIC,
            drawable.blood_taii_gloves,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(CRIT_RATE, 2),
                Stat(HIT_POINTS, 35),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Gloves of Destruction",
            "${Item.Type.GLOVES}19",
            Item.Type.GLOVES,
            2100,
            Item.Tier.LEGENDARY,
            drawable.bgod_gunshin_gloves,
            mutableListOf(
                Stat(ARMOR, 3),
                Stat(INTELLECT, 8),
                Stat(ACCURACY, 2),
                Stat(HIT_POINTS, 30),
                Stat(EVASION, 5)
            ),1
        ),
        Item(
            "Gloves of chaos",
            "${Item.Type.GLOVES}20",
            Item.Type.GLOVES,
            2300,
            Item.Tier.LEGENDARY,
            drawable.chaos_gloves,
            mutableListOf(
                Stat(ARMOR, 5),
                Stat(STRENGTH, 6),
                Stat(AGILITY, 6),
                Stat(HIT_POINTS, 60),
                Stat(EVASION, 3)
            ),1
        ),
        Item(
            "Dark Brotherhood gloves",
            "${Item.Type.GLOVES}21",
            Item.Type.GLOVES,
            3100,
            Item.Tier.LEGENDARY,
            drawable.darkb_gloves,
            mutableListOf(
                Stat(ARMOR, 3),
                Stat(AGILITY, 10),
                Stat(ACCURACY, 10),
                Stat(HIT_POINTS, 40),
                Stat(EVASION, 3)
            ),1
        ),
        Item(
            "Elder gloves",
            "${Item.Type.GLOVES}22",
            Item.Type.GLOVES,
            3300,
            Item.Tier.LEGENDARY,
            drawable.elder_silver_priest_gloves,
            mutableListOf(
                Stat(ARMOR, 5),
                Stat(HEAL, 2),
                Stat(WISDOM, 10),
                Stat(HIT_POINTS, 75),
                Stat(EVASION, 3)
            ),1
        )
    )
    var boots: MutableList<Item> = mutableListOf(
        Item(
            "Empty",
            "${Item.Type.BOOTS}0",
            Item.Type.BOOTS,
            10,
            Item.Tier.BASIC,
            drawable.empty_boots,
            mutableListOf(
                Stat(ARMOR, 1)
            )
        ),
        Item(
            "Basic shoes",
            "${Item.Type.BOOTS}1",
            Item.Type.BOOTS,
            10,
            Item.Tier.BASIC,
            drawable.priest_shoes_boots,
            mutableListOf(
                Stat(WISDOM, 1)
            ),1
        ),
        Item(
            "Basic boots",
            "${Item.Type.BOOTS}2",
            Item.Type.BOOTS,
            10,
            Item.Tier.BASIC,
            drawable.basic_boots,
            mutableListOf(
                Stat(AGILITY, 1)

            ),1
        ),
        Item(
            "Iron boots",
            "${Item.Type.BOOTS}3",
            Item.Type.BOOTS,
            115,
            Item.Tier.RARE,
            drawable.iron_sabat_boots,
            mutableListOf(
                Stat(ARMOR, 2)
            ),1
        ),
        Item(
            "Platinum boots",
            "${Item.Type.BOOTS}4",
            Item.Type.BOOTS,
            135,
            Item.Tier.RARE,
            drawable.zeus_plat_boots,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(STRENGTH, 2)
            ),1
        ),
        Item(
            "Silver boots",
            "${Item.Type.BOOTS}5",
            Item.Type.BOOTS,
            100,
            Item.Tier.RARE,
            drawable.silver_boots,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(WISDOM, 3)
            ),1
        ),
        Item(
            "Gold boots",
            "${Item.Type.BOOTS}6",
            Item.Type.BOOTS,
            110,
            Item.Tier.RARE,
            drawable.prince_boots,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(WISDOM, 3)
            ),1
        ),
        Item(
            "Black Death boots",
            "${Item.Type.BOOTS}7",
            Item.Type.BOOTS,
            330,
            Item.Tier.EPIC,
            drawable.bbod_darkb_taii_boots,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(AGILITY, 2)
            ),1
        ),
        Item(
            "Bloodmark boots",
            "${Item.Type.BOOTS}8",
            Item.Type.BOOTS,
            335,
            Item.Tier.EPIC,
            drawable.blood_king_boots,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(HIT_POINTS, 20)
            ),1
        ),
        Item(
            "Charge boots",
            "${Item.Type.BOOTS}9",
            Item.Type.BOOTS,
            360,
            Item.Tier.EPIC,
            drawable.charge_boots,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(DAMAGE, 4),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Mortal boots",
            "${Item.Type.BOOTS}10",
            Item.Type.BOOTS,
            380,
            Item.Tier.EPIC,
            drawable.arena_moral_boots,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(CRIT_RATE, 1),
                Stat(DAMAGE, 2),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Arena boots",
            "${Item.Type.BOOTS}11",
            Item.Type.BOOTS,
            350,
            Item.Tier.EPIC,
            drawable.arena_moral_boots,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(ACCURACY, 5),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "King's boots",
            "${Item.Type.BOOTS}12",
            Item.Type.BOOTS,
            250,
            Item.Tier.NOBLE,
            drawable.blood_king_boots,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(HIT_POINTS, 32),
                Stat(DAMAGE, 2),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Prince boots",
            "${Item.Type.BOOTS}13",
            Item.Type.BOOTS,
            140,
            Item.Tier.NOBLE,
            drawable.prince_boots,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(HIT_POINTS, 48),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Priest's boots",
            "${Item.Type.BOOTS}14",
            Item.Type.BOOTS,
            150,
            Item.Tier.NOBLE,
            drawable.priest_shoes_boots,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(WISDOM, 3),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Zeus's boots",
            "${Item.Type.BOOTS}15",
            Item.Type.BOOTS,
            850,
            Item.Tier.HEROIC,
            drawable.zeus_plat_boots,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(STRENGTH, 5),
                Stat(INTELLECT, 5),
                Stat(HIT_POINTS, 40),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "ZhangLiang's boots",
            "${Item.Type.BOOTS}16",
            Item.Type.BOOTS,
            1380,
            Item.Tier.HEROIC,
            drawable.chaos_zhang_boots,
            mutableListOf(
                Stat(ARMOR, 3),
                Stat(STRENGTH, 5),
                Stat(ACCURACY, 5),
                Stat(HIT_POINTS, 40),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Gunshin's boots",
            "${Item.Type.BOOTS}17",
            Item.Type.BOOTS,
            1350,
            Item.Tier.HEROIC,
            drawable.prince_boots,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(INTELLECT, 8),
                Stat(HIT_POINTS, 20),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Taii's boots",
            "${Item.Type.BOOTS}18",
            Item.Type.BOOTS,
            1250,
            Item.Tier.HEROIC,
            drawable.bbod_darkb_taii_boots,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(CRIT_RATE, 2),
                Stat(HIT_POINTS, 40),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Boots of Destruction",
            "${Item.Type.BOOTS}19",
            Item.Type.BOOTS,
            2100,
            Item.Tier.LEGENDARY,
            drawable.bbod_darkb_taii_boots,
            mutableListOf(
                Stat(ARMOR, 3),
                Stat(INTELLECT, 8),
                Stat(ACCURACY, 2),
                Stat(HIT_POINTS, 30),
                Stat(EVASION, 7)
            ),1
        ),
        Item(
            "Boots of chaos",
            "${Item.Type.BOOTS}20",
            Item.Type.BOOTS,
            2300,
            Item.Tier.LEGENDARY,
            drawable.chaos_zhang_boots,
            mutableListOf(
                Stat(ARMOR, 5),
                Stat(STRENGTH, 6),
                Stat(AGILITY, 6),
                Stat(HIT_POINTS, 60),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Dark Brotherhood boots",
            "${Item.Type.BOOTS}21",
            Item.Type.BOOTS,
            3100,
            Item.Tier.LEGENDARY,
            drawable.bbod_darkb_taii_boots,
            mutableListOf(
                Stat(ARMOR, 3),
                Stat(AGILITY, 12),
                Stat(ACCURACY, 5),
                Stat(HIT_POINTS, 40),
                Stat(EVASION, 4)

            ),1
        ),
        Item(
            "Elder boots",
            "${Item.Type.BOOTS}22",
            Item.Type.BOOTS,
            3300,
            Item.Tier.LEGENDARY,
            drawable.elder_boots,
            mutableListOf(
                Stat(ARMOR, 5),
                Stat(HEAL, 1),
                Stat(WISDOM, 7),
                Stat(HIT_POINTS, 75),
                Stat(EVASION, 3)
            ),1
        )
    )
    var chest: MutableList<Item> = mutableListOf(
        Item(
            "Empty",
            "${Item.Type.CHESTARMOR}0",
            Item.Type.CHESTARMOR,
            15,
            Item.Tier.BASIC,
            drawable.empty_chestarmor,
            mutableListOf(
                Stat(ARMOR, 2)
            ),1
        ),
        Item(
            "Basic tunic",
            "${Item.Type.CHESTARMOR}1",
            Item.Type.CHESTARMOR,
            15,
            Item.Tier.BASIC,
            drawable.tunic_chest,
            mutableListOf(
                Stat(ARMOR, 1),
                Stat(INTELLECT, 1)
            ),1
        ),
        Item(
            "Basic jerkin",
            "${Item.Type.CHESTARMOR}2",
            Item.Type.CHESTARMOR,
            15,
            Item.Tier.BASIC,
            drawable.jerkin_chest,
            mutableListOf(
                Stat(ARMOR, 1),
                Stat(AGILITY, 1)

            ),1
        ),
        Item(
            "Iron hauberk",
            "${Item.Type.CHESTARMOR}3",
            Item.Type.CHESTARMOR,
            215,
            Item.Tier.RARE,
            drawable.iron_chest,
            mutableListOf(
                Stat(ARMOR, 4)
            ),1
        ),
        Item(
            "Platinum hauberk",
            "${Item.Type.CHESTARMOR}4",
            Item.Type.CHESTARMOR,
            235,
            Item.Tier.RARE,
            drawable.zeus_plat_chest,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(STRENGTH, 3)
            ),1
        ),
        Item(
            "Silver hauberk",
            "${Item.Type.CHESTARMOR}5",
            Item.Type.CHESTARMOR,
            200,
            Item.Tier.RARE,
            drawable.silver_arena_chest,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(WISDOM, 4)
            ),1
        ),
        Item(
            "Gold hauberk",
            "${Item.Type.CHESTARMOR}6",
            Item.Type.CHESTARMOR,
            210,
            Item.Tier.RARE,
            drawable.gold_chest,
            mutableListOf(
                Stat(ARMOR, 2),
                Stat(WISDOM, 5)
            ),1
        ),
        Item(
            "Black Death hauberk",
            "${Item.Type.CHESTARMOR}7",
            Item.Type.CHESTARMOR,
            630,
            Item.Tier.EPIC,
            drawable.bhod_charge_chest,
            mutableListOf(
                Stat(ARMOR, 4),
                Stat(AGILITY, 4)
            ),1
        ),
        Item(
            "Bloodmark hauberk",
            "${Item.Type.CHESTARMOR}8",
            Item.Type.CHESTARMOR,
            735,
            Item.Tier.EPIC,
            drawable.gunshin_blood_chest,
            mutableListOf(
                Stat(ARMOR, 4),
                Stat(HIT_POINTS, 60)
            ),1
        ),
        Item(
            "Charge hauberk",
            "${Item.Type.CHESTARMOR}9",
            Item.Type.CHESTARMOR,
            860,
            Item.Tier.EPIC,
            drawable.bhod_charge_chest,
            mutableListOf(
                Stat(ARMOR, 5),
                Stat(DAMAGE, 6)
            ),1
        ),
        Item(
            "Mortal hauberk",
            "${Item.Type.CHESTARMOR}10",
            Item.Type.CHESTARMOR,
            780,
            Item.Tier.EPIC,
            drawable.mortal_chest,
            mutableListOf(
                Stat(ARMOR, 4),
                Stat(CRIT_RATE, 2),
                Stat(DAMAGE, 4),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Arena hauberk",
            "${Item.Type.CHESTARMOR}11",
            Item.Type.CHESTARMOR,
            700,
            Item.Tier.EPIC,
            drawable.silver_arena_chest,
            mutableListOf(
                Stat(ARMOR, 5),
                Stat(ACCURACY, 3)
            ),1
        ),
        Item(
            "King's hauberk",
            "${Item.Type.CHESTARMOR}12",
            Item.Type.CHESTARMOR,
            500,
            Item.Tier.NOBLE,
            drawable.king_chest,
            mutableListOf(
                Stat(ARMOR, 3),
                Stat(HIT_POINTS, 42),
                Stat(DAMAGE, 2),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Prince hauberk",
            "${Item.Type.CHESTARMOR}13",
            Item.Type.CHESTARMOR,
            340,
            Item.Tier.NOBLE,
            drawable.prince_chest,
            mutableListOf(
                Stat(ARMOR, 5),
                Stat(HIT_POINTS, 35),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Priest's hauberk",
            "${Item.Type.CHESTARMOR}14",
            Item.Type.CHESTARMOR,
            450,
            Item.Tier.NOBLE,
            drawable.priest_cloth_chest,
            mutableListOf(
                Stat(ARMOR, 4),
                Stat(WISDOM, 5),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "Zeus's hauberk",
            "${Item.Type.CHESTARMOR}15",
            Item.Type.CHESTARMOR,
            1450,
            Item.Tier.HEROIC,
            drawable.zeus_plat_chest,
            mutableListOf(
                Stat(ARMOR, 4),
                Stat(STRENGTH, 7),
                Stat(INTELLECT, 7),
                Stat(HIT_POINTS, 80),
                Stat(EVASION, 2)
            ),1
        ),
        Item(
            "ZhangLiang's hauberk",
            "${Item.Type.CHESTARMOR}16",
            Item.Type.CHESTARMOR,
            3380,
            Item.Tier.HEROIC,
            drawable.zhang_chest,
            mutableListOf(
                Stat(ARMOR, 5),
                Stat(STRENGTH, 8),
                Stat(ACCURACY, 4),
                Stat(HIT_POINTS, 100),
                Stat(EVASION, 3)
            ),1
        ),
        Item(
            "Gunshin's hauberk",
            "${Item.Type.CHESTARMOR}17",
            Item.Type.CHESTARMOR,
            2750,
            Item.Tier.HEROIC,
            drawable.gunshin_blood_chest,
            mutableListOf(
                Stat(ARMOR, 3),
                Stat(INTELLECT, 12),
                Stat(HIT_POINTS, 40),
                Stat(EVASION, 5)
            ),1
        ),
        Item(
            "Taii's hauberk",
            "${Item.Type.CHESTARMOR}18",
            Item.Type.CHESTARMOR,
            3250,
            Item.Tier.HEROIC,
            drawable.darb_taii_chest,
            mutableListOf(
                Stat(ARMOR, 4),
                Stat(CRIT_RATE, 4),
                Stat(HIT_POINTS, 70),
                Stat(EVASION, 4)
            ),1
        ),
        Item(
            "Armor of Destruction",
            "${Item.Type.CHESTARMOR}19",
            Item.Type.CHESTARMOR,
            4100,
            Item.Tier.LEGENDARY,
            drawable.bhod_charge_chest,
            mutableListOf(
                Stat(ARMOR, 3),
                Stat(INTELLECT, 15),
                Stat(ACCURACY, 4),
                Stat(HIT_POINTS, 60),
                Stat(EVASION, 11)
            ),1
        ),
        Item(
            "Hauberk of chaos",
            "${Item.Type.CHESTARMOR}20",
            Item.Type.CHESTARMOR,
            5300,
            Item.Tier.LEGENDARY,
            drawable.chaos_chest,
            mutableListOf(
                Stat(ARMOR, 6),
                Stat(STRENGTH, 15),
                Stat(AGILITY, 8),
                Stat(HIT_POINTS, 180),
                Stat(EVASION, 2),
                Stat(EVASION, 4)
            ),1
        ),
        Item(
            "Dark Brotherhood hauberk",
            "${Item.Type.CHESTARMOR}21",
            Item.Type.CHESTARMOR,
            4200,
            Item.Tier.LEGENDARY,
            drawable.darb_taii_chest,
            mutableListOf(
                Stat(ARMOR, 4),
                Stat(AGILITY, 20),
                Stat(ACCURACY, 5),
                Stat(HIT_POINTS, 110),
                Stat(EVASION, 5)
            ),1
        ),
        Item(
            "Elder hauberk",
            "${Item.Type.CHESTARMOR}22",
            Item.Type.CHESTARMOR,
            4300,
            Item.Tier.LEGENDARY,
            drawable.elder_chest,
            mutableListOf(
                Stat(ARMOR, 6),
                Stat(HEAL, 1),
                Stat(WISDOM, 10),
                Stat(HIT_POINTS, 220),
                Stat(EVASION, 4)
            ),1
        )
    )
    var weapon: MutableList<Item> = mutableListOf(
        Item(
            "Empty",
            "${Item.Type.WEAPON}0",
            Item.Type.WEAPON,
            25,
            Item.Tier.BASIC,
            drawable.empty_wep,
            mutableListOf(
                Stat(DAMAGE, 1)
            )
        ),
        Item(
            "Basic sword",
            "${Item.Type.WEAPON}1",
            Item.Type.WEAPON,
            25,
            Item.Tier.BASIC,
            drawable.sword_wep,
            mutableListOf(
                Stat(DAMAGE, 2),
                Stat(AGILITY, 1)
            ),
            1
        ),
        Item(
            "Basic mace",
            "${Item.Type.WEAPON}2",
            Item.Type.WEAPON,
            25,
            Item.Tier.BASIC,
            drawable.priest_wep,
            mutableListOf(
                Stat(DAMAGE, 2),
                Stat(WISDOM, 1)
            ),
            1
        ),
        Item(
            "Basic spellbook",
            "${Item.Type.WEAPON}3",
            Item.Type.WEAPON,
            25,
            Item.Tier.BASIC,
            drawable.book_wep,
            mutableListOf(
                Stat(DAMAGE, 3),
                Stat(INTELLECT, 1)

            ),
            2
        ),
        Item(
            "Basic bow",
            "${Item.Type.WEAPON}4",
            Item.Type.WEAPON,
            25,
            Item.Tier.BASIC,
            drawable.bow_wep,
            mutableListOf(
                Stat(DAMAGE, 3),
                Stat(AGILITY, 1)

            ),
            2
        ),
        Item(
            "Iron axe",
            "${Item.Type.WEAPON}5",
            Item.Type.WEAPON,
            1115,
            Item.Tier.RARE,
            drawable.ironaxe_wep,
            mutableListOf(
                Stat(DAMAGE, 4),
                Stat(ACCURACY, 2),
                Stat(STRENGTH, 2)
            ),
            1
        ),
        Item(
            "Iron greatsword",
            "${Item.Type.WEAPON}6",
            Item.Type.WEAPON,
            1235,
            Item.Tier.RARE,
            drawable.iron_wep,
            mutableListOf(
                Stat(DAMAGE, 5),
                Stat(ACCURACY, 3),
                Stat(STRENGTH, 3)
            ),
            2
        ),
        Item(
            "Wooden staff",
            "${Item.Type.WEAPON}7",
            Item.Type.WEAPON,
            1100,
            Item.Tier.RARE,
            drawable.wood_wep,
            mutableListOf(
                Stat(DAMAGE, 4),
                Stat(ACCURACY, 3),
                Stat(WISDOM, 3)
            ),
            2
        ),
        Item(
            "Fire orb",
            "${Item.Type.WEAPON}8",
            Item.Type.WEAPON,
            1310,
            Item.Tier.RARE,
            drawable.fire_wep,
            mutableListOf(
                Stat(DAMAGE, 7),
                Stat(ACCURACY, 3),
                Stat(INTELLECT, 3)
            ),
            2
        ),
        Item(
            "Black Death dagger",
            "${Item.Type.WEAPON}9",
            Item.Type.WEAPON,
            2230,
            Item.Tier.EPIC,
            drawable.blackdag_wep,
            mutableListOf(
                Stat(DAMAGE, 4),
                Stat(CRIT_RATE, 2),
                Stat(AGILITY, 3)
            ),
            1
        ),
        Item(
            "Mortal bow",
            "${Item.Type.WEAPON}10",
            Item.Type.WEAPON,
            2035,
            Item.Tier.EPIC,
            drawable.mortalbow_wep,
            mutableListOf(
                Stat(DAMAGE, 13),
                Stat(CRIT_RATE, 2),
                Stat(AGILITY, 4)
            ),
            2
        ),
        Item(
            "Charge axe",
            "${Item.Type.WEAPON}11",
            Item.Type.WEAPON,
            2360,
            Item.Tier.EPIC,
            drawable.charge_wep,
            mutableListOf(
                Stat(DAMAGE, 10),
                Stat(ACCURACY, 3),
                Stat(STRENGTH, 1),
                Stat(AGILITY, 1)
            ),
            1
        ),
        Item(
            "Mortal staff",
            "${Item.Type.WEAPON}12",
            Item.Type.WEAPON,
            2280,
            Item.Tier.EPIC,
            drawable.mortal_wep,
            mutableListOf(
                Stat(DAMAGE, 10),
                Stat(CRIT_RATE, 2),
                Stat(WISDOM, 7)
            ),
            2
        ),
        Item(
            "Black death sword",
            "${Item.Type.WEAPON}13",
            Item.Type.WEAPON,
            2400,
            Item.Tier.EPIC,
            drawable.black_wep,
            mutableListOf(
                Stat(DAMAGE, 6),
                Stat(CRIT_RATE, 2),
                Stat(AGILITY, 3)
            ),
            1
        ),
        Item(
            "King's greatsword",
            "${Item.Type.WEAPON}14",
            Item.Type.WEAPON,
            3000,
            Item.Tier.NOBLE,
            drawable.king_wep,
            mutableListOf(
                Stat(DAMAGE, 20),
                Stat(CRIT_RATE, 2),
                Stat(STRENGTH, 3)
            ),
            2
        ),
        Item(
            "Prince spellbook",
            "${Item.Type.WEAPON}15",
            Item.Type.WEAPON,
            3500,
            Item.Tier.NOBLE,
            drawable.prince_wep,
            mutableListOf(
                Stat(DAMAGE, 13),
                Stat(CRIT_RATE, 3),
                Stat(INTELLECT, 3)
            ),
            2
        ),
        Item(
            "Priest's mace",
            "${Item.Type.WEAPON}16",
            Item.Type.WEAPON,
            3450,
            Item.Tier.NOBLE,
            drawable.priest_wep,
            mutableListOf(
                Stat(DAMAGE, 3),
                Stat(ACCURACY, 3),
                Stat(WISDOM, 4)
            ),
            1
        ),
        Item(
            "Zeus's Spear",
            "${Item.Type.WEAPON}17",
            Item.Type.WEAPON,
            5450,
            Item.Tier.HEROIC,
            drawable.zeus_wep,
            mutableListOf(
                Stat(DAMAGE, 18),
                Stat(ACCURACY, 8),
                Stat(CRIT_RATE, 3)
            ),
            2
        ),
        Item(
            "ZhangLiang's Polearm",
            "${Item.Type.WEAPON}18",
            Item.Type.WEAPON,
            6200,
            Item.Tier.HEROIC,
            drawable.zhang_wep,
            mutableListOf(
                Stat(DAMAGE, 25),
                Stat(CRIT_RATE, 2),
                Stat(ACCURACY, 5)
            ),
            2
        ),
        Item(
            "Gunshin's Orb",
            "${Item.Type.WEAPON}19",
            Item.Type.WEAPON,
            6750,
            Item.Tier.HEROIC,
            drawable.gunshin_wep,
            mutableListOf(
                Stat(DAMAGE, 30),
                Stat(CRIT_RATE, 5),
                Stat(WISDOM, 10)
            ),
            2
        ),
        Item(
            "Taii's Bow",
            "${Item.Type.WEAPON}20",
            Item.Type.WEAPON,
            6250,
            Item.Tier.HEROIC,
            drawable.darkbow_wep,
            mutableListOf(
                Stat(DAMAGE, 22),
                Stat(CRIT_RATE, 6),
                Stat(AGILITY, 5)
            ),
            2
        ),
        Item(
            "Spellbook of Destruction",
            "${Item.Type.WEAPON}21",
            Item.Type.WEAPON,
            11000,
            Item.Tier.LEGENDARY,
            drawable.bsod_wep,
            mutableListOf(
                Stat(DAMAGE, 38),
                Stat(CRIT_RATE, 8),
                Stat(ACCURACY, 15),
                Stat(INTELLECT, 10)
            ),
            2
        ), Item(
            "Orb of Destruction",
            "${Item.Type.WEAPON}22",
            Item.Type.WEAPON,
            11000,
            Item.Tier.LEGENDARY,
            drawable.bood_wep,
            mutableListOf(
                Stat(DAMAGE, 45),
                Stat(CRIT_RATE, 5),
                Stat(ACCURACY, 10),
                Stat(INTELLECT, 15)
            ),
            2
        ),
        Item(
            "Axe of chaos",
            "${Item.Type.WEAPON}23",
            Item.Type.WEAPON,
            9500,
            Item.Tier.LEGENDARY,
            drawable.chaos_wep,
            mutableListOf(
                Stat(DAMAGE, 14),
                Stat(CRIT_RATE, 10),
                Stat(STRENGTH, 6),
                Stat(WISDOM, 3)
            ),
            1,
            listOf(
                ItemEffect(
                    "Void bolt",
                    "25% chance to fire a Void bolt on hit.",
                    ItemEffect.Type.DAMAGE_CHANCE_ON_HIT,
                    10,
                    15,
                    25f
                )
            )
        ),
        Item(
            "Dark Brotherhood Dagger",
            "${Item.Type.WEAPON}24",
            Item.Type.WEAPON,
            10500,
            Item.Tier.LEGENDARY,
            drawable.darkb_wep,
            mutableListOf(
                Stat(DAMAGE, 13),
                Stat(CRIT_RATE, 5),
                Stat(AGILITY, 10),
                Stat(ACCURACY, 12)
            ),
            1
        ),
        Item(
            "Dark Brotherhood Bow",
            "${Item.Type.WEAPON}25",
            Item.Type.WEAPON,
            10500,
            Item.Tier.LEGENDARY,
            drawable.darkbow_wep,
            mutableListOf(
                Stat(DAMAGE, 22),
                Stat(CRIT_RATE, 10),
                Stat(AGILITY, 10),
                Stat(ACCURACY, 12)
            ),
            2
        ),
        Item(
            "Elder Staff",
            "${Item.Type.WEAPON}26",
            Item.Type.WEAPON,
            12000,
            Item.Tier.LEGENDARY,
            drawable.elder_staff,
            mutableListOf(
                Stat(DAMAGE, 20),
                Stat(HEAL, 5),
                Stat(ACCURACY, 10),
                Stat(HIT_POINTS, 100),
                Stat(WISDOM, 8),
                Stat(ATTACK_SPEED, 4)
            ),
            2
        ),
        Item(
            "Elder Greatsword",
            "${Item.Type.WEAPON}27",
            Item.Type.WEAPON,
            12000,
            Item.Tier.LEGENDARY,
            drawable.eldergs_wep,
            mutableListOf(
                Stat(DAMAGE, 15),
                Stat(HEAL, 2),
                Stat(ACCURACY, 2),
                Stat(HIT_POINTS, 250),
                Stat(ARMOR, 2),
                Stat(ATTACK_SPEED, 4)
            ),
            2
        )
    )
}