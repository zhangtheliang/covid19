package learn.programming.battleoftheimmortals.database.model.actor

import android.animation.ObjectAnimator
import android.view.View
import androidx.interpolator.view.animation.FastOutSlowInInterpolator
import androidx.room.Entity
import androidx.room.Ignore
import kotlinx.android.synthetic.main.activity_fight.*
import kotlinx.android.synthetic.main.activity_fight.view.*
import learn.programming.battleoftheimmortals.database.DBM
import learn.programming.battleoftheimmortals.database.model.item.Item
import learn.programming.battleoftheimmortals.database.model.item.Item.Type.*
import learn.programming.battleoftheimmortals.utility.ItemObject
import learn.programming.battleoftheimmortals.utility.ItemObject.getItemByDbItem
import learn.programming.battleoftheimmortals.utility.ItemObject.weapon

@Entity(tableName = "Champion")
class Champion(
    var accountId: Int,
    name: String,
    raceId: Int,
    professionId: Int
) : Actor(raceId, professionId, name) {

    @Ignore
    var inventory: MutableList<Item> = mutableListOf()

    fun updateInventory() {
        if(inventory != null) inventory.clear()

        val items = DBM.getSharedInstance().inventoryItemDao().getAllForOwner(id)
        items.forEach {
            val item = getItemByDbItem(it) ?: return
            when(it.equipedSlot){
                SlotId.INVENTORY.id -> {
                    inventory.add(item)
                }
                SlotId.WEAPON_LEFT.id -> {
                    weapon1 = item
                }
                SlotId.WEAPON_RIGHT.id -> {
                    weapon2 = item
                }
                SlotId.HELMET.id -> {
                    helmet = item
                }
                SlotId.NECKLACE.id -> {
                    necklace = item
                }
                SlotId.EARRING_LEFT.id -> {
                   earring1 = item
                }
                SlotId.EARRING_RIGHT.id -> {
                    earring2 = item
                }
                SlotId.CHEST.id -> {
                   chestarmor = item
                }
                SlotId.GLOVES.id -> {
                   gloves = item
                }
                SlotId.RING_LEFT.id -> {
                    ring1 = item
                }
                SlotId.RING_RIGHT.id -> {
                    ring2 = item
                }
                SlotId.BOOTS.id -> {
                    boots = item
                }
                SlotId.BELT.id -> {
                    belt = item
                }
            }
        }
    }

    fun exchangeItem(item: Item) {
        when (item.type) {
            GLOVES -> {
                if (gloves.slotType != null) {
                    InventoryItem(id, gloves.id, SlotId.INVENTORY.id, gloves.dbID).saveToDB()
                    inventory.add(gloves)
                }
                InventoryItem(id, item.id, SlotId.GLOVES.id, item.dbID).saveToDB()
                gloves = item
            }
            BOOTS -> {
                if (boots.slotType != null) {
                    InventoryItem(id, boots.id, SlotId.INVENTORY.id, boots.dbID).saveToDB()
                    inventory.add(boots)
                }
                InventoryItem(id, item.id, SlotId.BOOTS.id, item.dbID).saveToDB()
                boots = item
            }
            BELT -> {
                if (belt.slotType != null) {
                    InventoryItem(id, belt.id, SlotId.INVENTORY.id, belt.dbID).saveToDB()
                    inventory.add(belt)
                }
                InventoryItem(id, item.id, SlotId.BELT.id, item.dbID).saveToDB()
                belt = item
            }
            CHESTARMOR -> {
                if (chestarmor.slotType != null) {
                    InventoryItem(id, chestarmor.id, SlotId.INVENTORY.id, chestarmor.dbID).saveToDB()
                    inventory.add(chestarmor)
                }
                InventoryItem(id, item.id, SlotId.CHEST.id, item.dbID).saveToDB()
                chestarmor = item
            }
            WEAPON -> {
                if (weapon1.slotType != null && item.slotType == 2 || weapon1.slotType == null && item.slotType == 2) {
                    if(weapon1.slotType != null){
                        InventoryItem(id, weapon1.id, SlotId.INVENTORY.id, weapon1.dbID).saveToDB()
                        inventory.add(weapon1)
                    }
                    if (weapon2.slotType != null) {
                        InventoryItem(id, weapon2.id, SlotId.INVENTORY.id, weapon2.dbID).saveToDB()
                        inventory.add(weapon2)
                        weapon2 = weapon[0]
                    }
                    InventoryItem(id, item.id, SlotId.WEAPON_LEFT.id, item.dbID).saveToDB()
                    weapon1 = item
                } else if (weapon1.slotType == null) {
                    InventoryItem(id, item.id, SlotId.WEAPON_LEFT.id, weapon1.dbID).saveToDB()
                    weapon1 = item
                } else if (weapon1 != null && weapon1.slotType == 1) {
                    if (weapon2.slotType != null) {
                        InventoryItem(id, weapon2.id, SlotId.INVENTORY.id, weapon2.dbID).saveToDB()
                        inventory.add(weapon2)
                    }
                    InventoryItem(id, item.id, SlotId.WEAPON_RIGHT.id, item.dbID).saveToDB()
                    weapon2 = item
                } else {
                    InventoryItem(id, weapon1.id, SlotId.INVENTORY.id, weapon1.dbID).saveToDB()
                    inventory.add(weapon1)
                    InventoryItem(id, item.id, SlotId.WEAPON_LEFT.id, item.dbID).saveToDB()
                    weapon1 = item
                }
            }
            RING -> {
                if (ring1.slotType == null) {
                    if (ring1.slotType != null) {
                        InventoryItem(id, ring1.id, SlotId.INVENTORY.id, ring1.dbID).saveToDB()
                        inventory.add(ring1)
                    }
                    InventoryItem(id, item.id, SlotId.RING_LEFT.id, item.dbID).saveToDB()
                    ring2 = item
                } else if (ring1 != ItemObject.rings[0]) {
                    if (ring2.slotType != null) {
                        InventoryItem(id, ring2.id, SlotId.INVENTORY.id, ring2.dbID).saveToDB()
                        inventory.add(ring2)
                    }
                    InventoryItem(id, item.id, SlotId.RING_RIGHT.id, item.dbID).saveToDB()
                    ring2 = item
                }
            }
            EARRING -> {
                if (earring1.slotType == null) {
                    if (earring1.slotType != null) {
                        InventoryItem(id, earring1.id, SlotId.INVENTORY.id, earring1.dbID).saveToDB()
                        inventory.add(earring1)
                    }
                    InventoryItem(id, item.id, SlotId.EARRING_LEFT.id, item.dbID).saveToDB()
                    earring1 = item
                } else if (earring1 != ItemObject.earrings[0]) {
                    if (earring2.slotType != null) {
                        InventoryItem(id, earring2.id, SlotId.INVENTORY.id, earring2.dbID).saveToDB()
                        inventory.add(earring2)
                    }
                    InventoryItem(id, item.id, SlotId.EARRING_RIGHT.id, item.dbID).saveToDB()
                    earring2 = item
                }
            }
            HELMET -> {
                if (helmet.slotType != null) {
                    InventoryItem(id, helmet.id, SlotId.INVENTORY.id, helmet.dbID).saveToDB()
                    inventory.add(helmet)
                }
                InventoryItem(id, item.id, SlotId.HELMET.id, item.dbID).saveToDB()
                helmet = item
            }
            NECKLACE -> {
                if (necklace.slotType != null) {
                    InventoryItem(id, necklace.id, SlotId.INVENTORY.id, necklace.dbID).saveToDB()
                    inventory.add(necklace)
                }
                InventoryItem(id, item.id, SlotId.NECKLACE.id, item.dbID).saveToDB()
                necklace = item
            }
        }
    }

    fun unequipItem(item: Item, list: MutableList<Item>): Item {
        var it = item

        if (item.slotType != null) {
            InventoryItem(id, item.id, SlotId.INVENTORY.id, item.dbID).saveToDB()
            it = list[0]
            updateAllStats()
        }
        return it
    }
}

