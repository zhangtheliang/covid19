package learn.programming.battleoftheimmortals.database.model.item

data class ItemLoot(
    val dropChance:Float,
    val item: Item?
)