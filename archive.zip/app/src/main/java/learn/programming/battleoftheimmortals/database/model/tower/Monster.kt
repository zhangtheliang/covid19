package learn.programming.battleoftheimmortals.database.model.tower

import learn.programming.battleoftheimmortals.database.model.actor.Actor
import learn.programming.battleoftheimmortals.database.model.item.Item
import learn.programming.battleoftheimmortals.database.model.item.ItemLoot


class Monster(
    name: String,
    raceID: Int,
    proffesionID: Int,
    val type: Type,
    val loot: List<ItemLoot?>,
    val mID: String? = null
) : Actor(raceID, proffesionID, name) {

    enum class Type {
        COMMON,
        UNCOMMON,
        RARE,
        EPIC,
        LEGENDARY
    }
}
