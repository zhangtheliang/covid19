package learn.programming.battleoftheimmortals.database.model.item

import learn.programming.battleoftheimmortals.database.model.actor.Champion
import learn.programming.battleoftheimmortals.database.model.item.ItemEffect.Type.*
import learn.programming.battleoftheimmortals.utility.FightSimulator

data class ItemEffect(val name: String, val desc: String, val type: Type) {
    enum class Type{
        DAMAGE_CHANCE_ON_HIT,
        ADD_STAT_ON_HIT,
        HEAL_ON_DAMAGE_RECEIVED,
        LIFESTEAL
    }

    var dmgFrom: Int? = null
    var dmgTo: Int? = null
    var chance: Float? = null

    //DAMAGE_CHANCE_ON_HIT
    constructor(name: String, desc: String, type: Type, dmgFrom: Int, dmgTo: Int, chance: Float) : this(name, desc, type){
        this.dmgFrom = dmgFrom
        this.dmgTo = dmgTo
        this.chance = chance
    }
    fun execute(caster: Champion, target: Champion){

        when(type) {
            DAMAGE_CHANCE_ON_HIT -> {
                val randomChance = (0..100).random()
                if (this.chance!! >= randomChance){
                    val randomDmg =(dmgFrom!!..dmgTo!!).random()
                    val dmgDone = target.takeDamage(randomDmg)
                    FightSimulator.combatLog += "${caster.name} used $name. ${target.name} takes $dmgDone damage\n"
                }
            }
            ADD_STAT_ON_HIT -> {

            }
            HEAL_ON_DAMAGE_RECEIVED -> {

            }
            LIFESTEAL -> {

            }
        }
    }
}
