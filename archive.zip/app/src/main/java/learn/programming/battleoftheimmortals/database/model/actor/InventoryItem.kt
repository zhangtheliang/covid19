package learn.programming.battleoftheimmortals.database.model.actor

import androidx.room.Entity
import androidx.room.PrimaryKey
import learn.programming.battleoftheimmortals.database.DBM
import java.util.*

@Entity(tableName = "InventoryItem")
class InventoryItem(
    val ownerID: Int,
    val itemID: String,
    val equipedSlot: Int,

    @PrimaryKey
    var id: String = UUID.randomUUID().toString()
) {
    init {
        if(id == "") id = UUID.randomUUID().toString()
    }
    fun saveToDB() {
        DBM.getSharedInstance().inventoryItemDao().save(this)
    }
}