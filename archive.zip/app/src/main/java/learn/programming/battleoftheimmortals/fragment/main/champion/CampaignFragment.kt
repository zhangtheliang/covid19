package learn.programming.battleoftheimmortals.fragment.main.champion

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.fragment_campaign.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.adapter.ChooseChampionSpinner
import learn.programming.battleoftheimmortals.utility.AccountObject

class CampaignFragment : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_campaign, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        chooseChampionSPINNER3.adapter = ChooseChampionSpinner(
            this.context!!,
            AccountObject.currentAccount?.champions?.toList() ?: listOf()
        )
        chooseChampionSPINNER3.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    val currentChampion = AccountObject.currentAccount!!.champions[position]
                    hpTV.text = currentChampion.hitPoints.value.toString()
                    armorTV.text = currentChampion.armor.value.toString()
                    damageTV.text = currentChampion.damage.value.toString()
                    healTV.text = currentChampion.heal.value.toString()
                }

            }
    }
}
