package learn.programming.battleoftheimmortals.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.main_row_item.view.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.database.model.actor.Champion

class InventoryListViewAdapter (val context: Context, var champ: Champion) : BaseAdapter() {
    val thisContext: Context
    init {
        thisContext = context
    }

    override fun getCount(): Int {
        return champ.inventory.size
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getItem(position: Int): Any {
        return ""
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {

        val inflater = LayoutInflater.from(thisContext)
        var view = convertView
        if(view == null){
            view = inflater.inflate(R.layout.main_row_item, parent,false)
        }
        if (champ.inventory.size > position) {
            var item = champ.inventory[position]


            view?.equipBtn?.setOnClickListener {
                champ.exchangeItem(item)
                champ.inventory.remove(item)
                champ.updateAllStats()
                notifyDataSetChanged()
                Toast.makeText(context, "Item equiped", Toast.LENGTH_LONG).show()
            }
            view?.sellBtn?.setOnClickListener {
                champ.inventory.remove(item)
                notifyDataSetChanged()
                Toast.makeText(context, "Item sold", Toast.LENGTH_LONG).show()
            }
            view?.itemNameTV?.setText(item.name)
            view?.itemIcon?.updateView(item)
            val parsedAttrs = item.statsToString()
            view?.itemAttributesTV?.text = parsedAttrs
        }else{
            view?.equipBtn?.visibility = View.INVISIBLE
                view?.sellBtn?.visibility = View.INVISIBLE
                view?.itemNameTV?.visibility = View.INVISIBLE
            view?.itemIcon?.visibility = View.INVISIBLE
            view?.itemAttributesTV?.visibility = View.INVISIBLE
        }
        return view ?: View(context)
    }
}