package learn.programming.battleoftheimmortals.database.model.tower

import learn.programming.battleoftheimmortals.database.model.actor.Actor
import learn.programming.battleoftheimmortals.database.model.item.Item
import learn.programming.battleoftheimmortals.database.model.item.ItemLoot

class Floor(
    val ID: Int,
    val name: String,
    val monsters: List<Monster?>,
    val specialRewards: List<Item>? = null
)
