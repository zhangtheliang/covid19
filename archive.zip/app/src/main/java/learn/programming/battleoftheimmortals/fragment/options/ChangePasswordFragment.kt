package learn.programming.battleoftheimmortals.fragment.options


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.fragment_change_password.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.database.DBM
import learn.programming.battleoftheimmortals.utility.AccountObject

/**
 * A simple [Fragment] subclass.
 */
class ChangePasswordFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_change_password, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        confirmPasswordChangeBtn.setOnClickListener {

            //Change Account Password
            if (oldPasswordET.text.toString() == AccountObject.currentAccount?.instance?.password) {
                if (newPasswordET.text.toString() == confirmPasswordET.text.toString()) {
                    AccountObject.currentAccount?.instance?.password = newPasswordET.text.toString()
                    DBM.getSharedInstance().accountDao().changePassword(
                        AccountObject.currentAccount?.instance?.password!!,
                        AccountObject.currentAccount?.instance?.id!!
                    )
                    Toast.makeText(context, "Your password has been changed.", Toast.LENGTH_SHORT)
                        .show()
                } else {
                    Toast.makeText(context, "Passwords don't match.", Toast.LENGTH_SHORT).show()
                }

            } else {
                Toast.makeText(context, "Current Password is incorrect", Toast.LENGTH_SHORT).show()
            }
        }
    }


}
