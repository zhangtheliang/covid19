package learn.programming.battleoftheimmortals.database.model.actor

import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.database.model.actor.Race.ActorType.CHAMPION
import learn.programming.battleoftheimmortals.database.model.actor.Race.ActorType.MONSTER

enum class Race(
    val id: Int,
    val actorType: ActorType,
    val strenght: Int,
    val agility: Int,
    val intellect: Int,
    val wisdom: Int,
    val icon: Int
) {
    //CHAMPION
    HUMAN(0, CHAMPION, 10, 8, 8, 8, R.drawable.human),
    ORC(1,CHAMPION, 18, 5, 6, 5, R.drawable.orc),
    ELF(2, CHAMPION, 6, 10, 8, 10, R.drawable.elf),

    //MONSTER
    TROLL(3, MONSTER, 25, 3, 0, 12, R.drawable.ic_orc),
    GOBLIN(4, MONSTER, 7, 13, 15, 10, R.drawable.ic_orc),
    WOLF(5, MONSTER, 7, 13, 15, 10, R.drawable.ic_orc),
    BEAR(6, MONSTER, 25, 3, 0, 12, R.drawable.ic_orc),
    SPIDER(7, MONSTER, 7, 13, 15, 10, R.drawable.ic_orc);

    enum class ActorType{
        CHAMPION,
        MONSTER
    }
    companion object {
        fun getById(id: Int) : Race {
            return Race.values().filter { it.id == id }.first()
        }
    }
}