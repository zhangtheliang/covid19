package learn.programming.battleoftheimmortals.fragment.main.shop


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.fragment_item_shop.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.activity.MainActivity
import learn.programming.battleoftheimmortals.database.model.actor.Champion

/**
 * A simple [Fragment] subclass.
 */
class ItemShopFragment(var champ: Champion) : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_item_shop, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        weaponBtn.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(WeaponShopFragment(champ))
        }
        helmetBtn.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(HelmetShopFragment(champ))
        }
        chestArmorBtn.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(ChestarmorShopFragment(champ))
        }
        glovesBtn.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(GlovesShopFragment(champ))
        }
        bootsBtn.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(BootsShopFragment(champ))
        }
        necklaceBtn.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(NecklaceShopFragment(champ))
        }
        earingBtn.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(EaringShopFragment(champ))
        }
        ringBtn.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(RingShopFragment(champ))
        }
        beltBtn.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(BeltShopFragment(champ))
        }
    }


}
