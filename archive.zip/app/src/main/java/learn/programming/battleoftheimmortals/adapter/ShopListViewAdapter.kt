package learn.programming.battleoftheimmortals.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.main_row_shop.view.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.database.model.actor.Actor
import learn.programming.battleoftheimmortals.database.model.actor.Champion
import learn.programming.battleoftheimmortals.database.model.actor.InventoryItem
import learn.programming.battleoftheimmortals.database.model.item.Item

class ShopListViewAdapter(var context: Context, var list: MutableList<Item>, var champ: Champion): BaseAdapter() {
    override fun getCount(): Int {
        return list.size
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getItem(position: Int): Any {
        return ""
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var inflater = LayoutInflater.from(context)
        var item = list[position]
        var view = convertView
        view = inflater.inflate(R.layout.main_row_shop, parent, false)
        view.itemNameTV.setText(item.name)
        view.itemIcon.updateView(item)
        view.priceTV.setText("Price:${item.goldValue}")
        val parsedAttrs = item.statsToString()
        view.itemAttributesTV.text = parsedAttrs
        view.buyBtn.setOnClickListener {
            InventoryItem(champ.id, item.id, Actor.SlotId.INVENTORY.id).saveToDB()
            Toast.makeText(context,"Item added to your items",Toast.LENGTH_LONG).show()
            champ.updateAllStats()
        }
        return view
    }

}