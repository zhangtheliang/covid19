package learn.programming.battleoftheimmortals.database.dao

import androidx.room.*
import learn.programming.battleoftheimmortals.database.model.actor.Champion

@Dao
interface ChampionDao{
    @Query("SELECT * FROM Champion")
    fun getAll() : List<Champion>

    @Transaction
    @Query("SELECT * FROM Champion WHERE name=:name LIMIT 1")
    fun validateCreateCharacterCredentials(name: String) : Champion?

    @Transaction
    @Insert
    fun save(champion: Champion)

    @Delete
    fun remove(champion: Champion)

    @Query("SELECT * FROM Champion WHERE id=:id LIMIT 1")
    fun getByID(id: Int): Champion?

    @Update
    fun updateChamp(champ: Champion)
}
