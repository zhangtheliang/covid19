package learn.programming.battleoftheimmortals.fragment.main


import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.fragment_main_menu.*
import learn.programming.battleoftheimmortals.R
import learn.programming.battleoftheimmortals.activity.LoginActivity
import learn.programming.battleoftheimmortals.activity.MainActivity
import learn.programming.battleoftheimmortals.fragment.main.champion.ArenaFragment
import learn.programming.battleoftheimmortals.fragment.main.champion.CampaignFragment
import learn.programming.battleoftheimmortals.fragment.main.champion.TowerFragment
import learn.programming.battleoftheimmortals.fragment.main.champion.YourChampionsFragment
import learn.programming.battleoftheimmortals.utility.AccountObject

class MainMenuFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_main_menu, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        AccountObject.currentAccount!!.champions.forEach {
            it.updateInventory()
            it.updateAllStats()
        }

        buttonYourChampion.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(YourChampionsFragment())
        }
        buttonArena.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(ArenaFragment())
        }
        buttonCampaign.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(CampaignFragment())
        }
        buttonLogOut.setOnClickListener {
            val intent = Intent(this.context, LoginActivity::class.java)
            startActivity(intent)
        }
        buttonTower.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(TowerFragment())
        }

        buttonOptions.setOnClickListener {
            (activity as MainActivity).changeFragmentTo(OptionsFragment())
        }
    }


}
